import { DurableFunctionTestRunner } from "@aws/durable-execution-sdk-js-testing";
import { handler } from "./app";
/**
 * ============================================================================
 * LOCAL TESTING with AWS Durable Execution Testing SDK
 * ============================================================================
 *
 * This runs the durable function LOCALLY without deploying to AWS.
 * The test runner simulates the durable execution environment.
 *
 * Run with: pnpm test
 * ============================================================================
 */
describe("Reservation Workflow", () => {
    test("creates reservation and processes through all steps", async () => {
        const runner = new DurableFunctionTestRunner({ handler });
        const result = await runner.run({
            seatId: "A1",
            userId: "user-123",
        });
        // Verify execution succeeded
        expect(result.status).toBe("SUCCEEDED");
        // Verify final result
        expect(result.result.message).toBe("Reservation workflow completed");
        expect(result.result.reservation.seatId).toBe("A1");
        expect(result.result.reservation.status).toBe("expired");
        // Inspect individual steps
        const steps = result.getOperations();
        console.log("Steps executed:", steps.length);
    });
    test("step 1 creates hold with correct data", async () => {
        const runner = new DurableFunctionTestRunner({ handler });
        const result = await runner.run({
            seatId: "B2",
            userId: "user-456",
        });
        expect(result.status).toBe("SUCCEEDED");
        expect(result.result.reservation.seatId).toBe("B2");
        expect(result.result.reservation.userId).toBe("user-456");
    });
});
