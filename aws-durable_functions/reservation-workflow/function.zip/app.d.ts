import { DurableContext } from "@aws/durable-execution-sdk-js";
/**
 * ============================================================================
 * AWS LAMBDA DURABLE FUNCTIONS - Reservation Workflow Demo
 * ============================================================================
 *
 * ONE Lambda function with MULTIPLE STEPS demonstrating:
 * - context.step()  → Creates checkpoint (won't re-run on replay)
 * - context.wait()  → Suspends execution (no compute cost during wait)
 * - Replay          → On resume, stored results are used, not re-executed
 *
 * IMPORTANT LIMITATIONS:
 * - Only available in us-east-2 region
 * - Durable execution must be enabled at function CREATION time
 * - Cannot add durable execution to existing functions
 *
 * ============================================================================
 */
interface ReservationEvent {
    seatId: string;
    userId?: string;
}
/**
 * The Durable Reservation Workflow
 *
 * Flow:
 *   STEP 1: Create hold → WAIT 15 min → STEP 2: Expire if not confirmed
 */
export declare const handler: (event: ReservationEvent, context: DurableContext) => Promise<{
    message: string;
    reservation: {
        status: "expired";
        expiredAt: string;
        reservationId: string;
        seatId: string;
        userId?: string;
        createdAt: string;
        expiresAt: string;
    };
}>;
export {};
