"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// app.ts
var app_exports = {};
__export(app_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(app_exports);

// node_modules/.pnpm/@aws+durable-execution-sdk-js@1.0.0/node_modules/@aws/durable-execution-sdk-js/dist/index.mjs
var import_client_lambda = require("@aws-sdk/client-lambda");
var import_events = require("events");
var import_async_hooks = require("async_hooks");
var import_crypto = require("crypto");
var import_node_console = require("node:console");
var import_node_util = __toESM(require("node:util"), 1);
var DurableExecutionMode;
(function(DurableExecutionMode2) {
  DurableExecutionMode2["ExecutionMode"] = "ExecutionMode";
  DurableExecutionMode2["ReplayMode"] = "ReplayMode";
  DurableExecutionMode2["ReplaySucceededContext"] = "ReplaySucceededContext";
})(DurableExecutionMode || (DurableExecutionMode = {}));
var InvocationStatus;
(function(InvocationStatus2) {
  InvocationStatus2["SUCCEEDED"] = "SUCCEEDED";
  InvocationStatus2["FAILED"] = "FAILED";
  InvocationStatus2["PENDING"] = "PENDING";
})(InvocationStatus || (InvocationStatus = {}));
var OperationSubType;
(function(OperationSubType2) {
  OperationSubType2["STEP"] = "Step";
  OperationSubType2["WAIT"] = "Wait";
  OperationSubType2["CALLBACK"] = "Callback";
  OperationSubType2["RUN_IN_CHILD_CONTEXT"] = "RunInChildContext";
  OperationSubType2["MAP"] = "Map";
  OperationSubType2["MAP_ITERATION"] = "MapIteration";
  OperationSubType2["PARALLEL"] = "Parallel";
  OperationSubType2["PARALLEL_BRANCH"] = "ParallelBranch";
  OperationSubType2["WAIT_FOR_CALLBACK"] = "WaitForCallback";
  OperationSubType2["WAIT_FOR_CONDITION"] = "WaitForCondition";
  OperationSubType2["CHAINED_INVOKE"] = "ChainedInvoke";
})(OperationSubType || (OperationSubType = {}));
var DurableLogLevel;
(function(DurableLogLevel2) {
  DurableLogLevel2["INFO"] = "INFO";
  DurableLogLevel2["WARN"] = "WARN";
  DurableLogLevel2["ERROR"] = "ERROR";
  DurableLogLevel2["DEBUG"] = "DEBUG";
})(DurableLogLevel || (DurableLogLevel = {}));
var StepSemantics;
(function(StepSemantics2) {
  StepSemantics2["AtMostOncePerRetry"] = "AT_MOST_ONCE_PER_RETRY";
  StepSemantics2["AtLeastOncePerRetry"] = "AT_LEAST_ONCE_PER_RETRY";
})(StepSemantics || (StepSemantics = {}));
var JitterStrategy;
(function(JitterStrategy2) {
  JitterStrategy2["NONE"] = "NONE";
  JitterStrategy2["FULL"] = "FULL";
  JitterStrategy2["HALF"] = "HALF";
})(JitterStrategy || (JitterStrategy = {}));
var BatchItemStatus;
(function(BatchItemStatus2) {
  BatchItemStatus2["SUCCEEDED"] = "SUCCEEDED";
  BatchItemStatus2["FAILED"] = "FAILED";
  BatchItemStatus2["STARTED"] = "STARTED";
})(BatchItemStatus || (BatchItemStatus = {}));
var DurablePromise = class {
  /**
   * The actual promise instance, created only when execution begins.
   * Starts as null and remains null until the DurablePromise is first awaited
   * or chained (.then/.catch/.finally). Once created, it holds the running
   * promise returned by the _executor function.
   *
   * Example lifecycle:
   * ```typescript
   * const dp = new DurablePromise(() => fetch('/api')); // _promise = null
   * console.log(dp.isExecuted); // false
   *
   * const result = await dp; // NOW _promise = fetch('/api') promise
   * console.log(dp.isExecuted); // true
   * ```
   *
   * This lazy initialization prevents the executor from running until needed.
   */
  _promise = null;
  /**
   * Function that contains the deferred execution logic.
   * This function is NOT called when the DurablePromise is created - it's only
   * executed when the promise is first awaited or chained (.then/.catch/.finally).
   *
   * Example:
   * ```typescript
   * const durablePromise = new DurablePromise(async () => {
   *   console.log("This runs ONLY when awaited, not when created");
   *   return await someAsyncOperation();
   * });
   *
   * // At this point, nothing has executed yet
   * console.log("Promise created but not executed");
   *
   * // NOW the executor function runs
   * const result = await durablePromise;
   * ```
   */
  _executor;
  /** Flag indicating whether the promise has been executed (awaited or chained) */
  _isExecuted = false;
  /**
   * Creates a new DurablePromise
   * @param executor - Function containing the deferred execution logic
   */
  constructor(executor) {
    this._executor = executor;
  }
  /**
   * Ensures the promise is executed, creating the actual promise if needed
   * @returns The underlying promise instance
   */
  ensureExecution() {
    if (!this._promise) {
      this._isExecuted = true;
      this._promise = this._executor();
    }
    return this._promise;
  }
  /**
   * Attaches callbacks for the resolution and/or rejection of the Promise
   * Triggers execution if not already started
   */
  then(onfulfilled, onrejected) {
    return this.ensureExecution().then(onfulfilled, onrejected);
  }
  /**
   * Attaches a callback for only the rejection of the Promise
   * Triggers execution if not already started
   */
  catch(onrejected) {
    return this.ensureExecution().catch(onrejected);
  }
  /**
   * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected)
   * Triggers execution if not already started
   */
  finally(onfinally) {
    return this.ensureExecution().finally(onfinally);
  }
  /** Returns the string tag for the promise type */
  get [Symbol.toStringTag]() {
    return "DurablePromise";
  }
  /**
   * Check if the promise has been executed (awaited or had .then/.catch/.finally called)
   * @returns true if execution has started, false otherwise
   */
  get isExecuted() {
    return this._isExecuted;
  }
};
function durationToSeconds(duration) {
  const days = "days" in duration ? duration.days ?? 0 : 0;
  const hours = "hours" in duration ? duration.hours ?? 0 : 0;
  const minutes = "minutes" in duration ? duration.minutes ?? 0 : 0;
  const seconds = "seconds" in duration ? duration.seconds ?? 0 : 0;
  return days * 24 * 60 * 60 + hours * 60 * 60 + minutes * 60 + seconds;
}
var safeStringify = (data) => {
  try {
    const seen = /* @__PURE__ */ new WeakSet();
    return JSON.stringify(data, (key, value) => {
      if (typeof value === "object" && value !== null) {
        if (seen.has(value))
          return "[Circular]";
        seen.add(value);
        if (value instanceof Error) {
          return {
            ...value,
            name: value.name,
            message: value.message,
            stack: value.stack
          };
        }
      }
      return value;
    }, 2);
  } catch {
    return "[Unable to stringify]";
  }
};
var log = (emoji, message, data) => {
  if (process.env.DURABLE_VERBOSE_MODE === "true") {
    console.debug(`${emoji} ${message}`, data ? safeStringify(data) : "");
  }
};
var TerminationReason;
(function(TerminationReason2) {
  TerminationReason2["OPERATION_TERMINATED"] = "OPERATION_TERMINATED";
  TerminationReason2["RETRY_SCHEDULED"] = "RETRY_SCHEDULED";
  TerminationReason2["RETRY_INTERRUPTED_STEP"] = "RETRY_INTERRUPTED_STEP";
  TerminationReason2["WAIT_SCHEDULED"] = "WAIT_SCHEDULED";
  TerminationReason2["CALLBACK_PENDING"] = "CALLBACK_PENDING";
  TerminationReason2["CHECKPOINT_FAILED"] = "CHECKPOINT_FAILED";
  TerminationReason2["SERDES_FAILED"] = "SERDES_FAILED";
  TerminationReason2["CONTEXT_VALIDATION_ERROR"] = "CONTEXT_VALIDATION_ERROR";
  TerminationReason2["CUSTOM"] = "CUSTOM";
})(TerminationReason || (TerminationReason = {}));
var asyncLocalStorage = new import_async_hooks.AsyncLocalStorage();
var getActiveContext = () => {
  return asyncLocalStorage.getStore();
};
var runWithContext = (contextId, parentId, fn, attempt, durableExecutionMode) => {
  return asyncLocalStorage.run({ contextId, parentId, attempt, durableExecutionMode }, fn);
};
var validateContextUsage = (operationContextId, operationName, terminationManager) => {
  const contextId = operationContextId || "root";
  const activeContext = getActiveContext();
  if (!activeContext) {
    return;
  }
  if (activeContext.contextId !== contextId) {
    const errorMessage = `Context usage error in "${operationName}": You are using a parent or sibling context instead of the current child context. Expected context ID: "${activeContext.contextId}", but got: "${operationContextId}". When inside runInChildContext(), you must use the child context parameter, not the parent context.`;
    terminationManager.terminate({
      reason: TerminationReason.CONTEXT_VALIDATION_ERROR,
      message: errorMessage,
      error: new Error(errorMessage)
    });
  }
};
var HASH_LENGTH = 16;
var hashId = (input) => {
  return (0, import_crypto.createHash)("md5").update(input).digest("hex").substring(0, HASH_LENGTH);
};
var getStepData = (stepData, stepId) => {
  const hashedId = hashId(stepId);
  return stepData[hashedId];
};
function hasFinishedAncestor(context, parentId) {
  if (!parentId) {
    log("\u{1F50D}", "hasFinishedAncestor: No parentId provided");
    return false;
  }
  if (hasPendingAncestorCompletion(context, parentId)) {
    log("\u{1F50D}", "hasFinishedAncestor: Found ancestor with pending completion!", {
      parentId
    });
    return true;
  }
  let currentHashedId = hashId(parentId);
  log("\u{1F50D}", "hasFinishedAncestor: Starting check", {
    parentId,
    initialHashedId: currentHashedId
  });
  while (currentHashedId) {
    const parentOperation = context._stepData[currentHashedId];
    log("\u{1F50D}", "hasFinishedAncestor: Checking operation", {
      hashedId: currentHashedId,
      hasOperation: !!parentOperation,
      status: parentOperation?.Status,
      type: parentOperation?.Type
    });
    if (parentOperation?.Status === import_client_lambda.OperationStatus.SUCCEEDED || parentOperation?.Status === import_client_lambda.OperationStatus.FAILED) {
      log("\u{1F50D}", "hasFinishedAncestor: Found finished ancestor!", {
        hashedId: currentHashedId,
        status: parentOperation.Status
      });
      return true;
    }
    currentHashedId = parentOperation?.ParentId;
  }
  log("\u{1F50D}", "hasFinishedAncestor: No finished ancestor found");
  return false;
}
function hasPendingAncestorCompletion(context, stepId) {
  let currentHashedId = hashId(stepId);
  while (currentHashedId) {
    if (context.pendingCompletions.has(currentHashedId)) {
      return true;
    }
    const operation = context._stepData[currentHashedId];
    currentHashedId = operation?.ParentId;
  }
  return false;
}
function terminate(context, reason, message) {
  const activeContext = getActiveContext();
  if (activeContext?.parentId) {
    return new Promise(async (_resolve, _reject) => {
      await new Promise((resolve) => setImmediate(resolve));
      log("\u{1F50D}", "Terminate called - checking context:", {
        hasActiveContext: !!activeContext,
        contextId: activeContext?.contextId,
        parentId: activeContext?.parentId,
        reason,
        message
      });
      const ancestorFinished = hasFinishedAncestor(context, activeContext.parentId);
      log("\u{1F50D}", "Ancestor check result:", {
        parentId: activeContext.parentId,
        ancestorFinished
      });
      if (ancestorFinished) {
        log("\u{1F6D1}", "Skipping termination - ancestor already finished:", {
          contextId: activeContext.contextId,
          parentId: activeContext.parentId,
          reason,
          message
        });
        return;
      }
      const tracker2 = context.activeOperationsTracker;
      if (tracker2 && tracker2.hasActive()) {
        log("\u23F3", "Deferring termination - active operations in progress:", {
          activeCount: tracker2.getCount(),
          reason,
          message
        });
        const checkInterval = setInterval(() => {
          if (!tracker2.hasActive()) {
            clearInterval(checkInterval);
            log("\u2705", "Active operations completed, proceeding with termination:", {
              reason,
              message
            });
            context.terminationManager.terminate({
              reason,
              message
            });
          }
        }, 10);
        return;
      }
      context.terminationManager.terminate({
        reason,
        message
      });
    });
  }
  const tracker = context.activeOperationsTracker;
  if (tracker && tracker.hasActive()) {
    log("\u23F3", "Deferring termination - active operations in progress:", {
      activeCount: tracker.getCount(),
      reason,
      message
    });
    return new Promise((_resolve, _reject) => {
      const checkInterval = setInterval(() => {
        if (!tracker.hasActive()) {
          clearInterval(checkInterval);
          log("\u2705", "Active operations completed, proceeding with termination:", {
            reason,
            message
          });
          context.terminationManager.terminate({
            reason,
            message
          });
        }
      }, 10);
    });
  }
  context.terminationManager.terminate({
    reason,
    message
  });
  return new Promise(() => {
  });
}
function terminateForUnrecoverableError(context, error, stepIdentifier) {
  return terminate(context, error.terminationReason, `Unrecoverable error in step ${stepIdentifier}: ${error.message}`);
}
var DEFAULT_CONFIG$1 = {
  maxAttempts: 3,
  initialDelay: { seconds: 5 },
  maxDelay: { minutes: 5 },
  backoffRate: 2,
  jitter: JitterStrategy.FULL,
  retryableErrors: [/.*/],
  // By default, retry all errors
  retryableErrorTypes: []
};
var applyJitter$1 = (delay, strategy) => {
  switch (strategy) {
    case JitterStrategy.NONE:
      return delay;
    case JitterStrategy.FULL:
      return Math.random() * delay;
    case JitterStrategy.HALF:
      return delay / 2 + Math.random() * (delay / 2);
    default:
      return delay;
  }
};
var createRetryStrategy = (config = {}) => {
  const shouldUseDefaultErrors = config.retryableErrors === void 0 && config.retryableErrorTypes === void 0;
  const finalConfig = {
    ...DEFAULT_CONFIG$1,
    ...config,
    retryableErrors: config.retryableErrors ?? (shouldUseDefaultErrors ? [/.*/] : [])
  };
  return (error, attemptsMade) => {
    if (attemptsMade >= finalConfig.maxAttempts) {
      return { shouldRetry: false };
    }
    const isRetryableErrorMessage = finalConfig.retryableErrors.some((pattern) => {
      if (pattern instanceof RegExp) {
        return pattern.test(error.message);
      }
      return error.message.includes(pattern);
    });
    const isRetryableErrorType = finalConfig.retryableErrorTypes.some((ErrorType) => error instanceof ErrorType);
    if (!isRetryableErrorMessage && !isRetryableErrorType) {
      return { shouldRetry: false };
    }
    const initialDelaySeconds = durationToSeconds(finalConfig.initialDelay);
    const maxDelaySeconds = durationToSeconds(finalConfig.maxDelay);
    const baseDelay = Math.min(initialDelaySeconds * Math.pow(finalConfig.backoffRate, attemptsMade - 1), maxDelaySeconds);
    const delayWithJitter = applyJitter$1(baseDelay, finalConfig.jitter);
    const finalDelay = Math.max(1, Math.round(delayWithJitter));
    return { shouldRetry: true, delay: { seconds: finalDelay } };
  };
};
var retryPresets = {
  /**
   * Default retry strategy with exponential backoff
   * - 6 total attempts (1 initial + 5 retries)
   * - Initial delay: 5 seconds
   * - Max delay: 60 seconds
   * - Backoff rate: 2x
   * - Jitter: FULL (randomizes delay between 0 and calculated delay)
   * - Total max wait time less than 150 seconds (2:30)
   */
  default: createRetryStrategy({
    maxAttempts: 6,
    initialDelay: { seconds: 5 },
    maxDelay: { seconds: 60 },
    backoffRate: 2,
    jitter: JitterStrategy.FULL
  }),
  /**
   * No retry strategy - fails immediately on first error
   * - 1 total attempt (no retries)
   */
  noRetry: createRetryStrategy({
    maxAttempts: 1
  })
};
var StepInterruptedError = class extends Error {
  constructor(_stepId, _stepName) {
    super(`The step execution process was initiated but failed to reach completion due to an interruption.`);
    this.name = "StepInterruptedError";
  }
};
var OPERATIONS_COMPLETE_EVENT = "allOperationsComplete";
var DurableOperationError = class extends Error {
  cause;
  errorData;
  stackTrace;
  constructor(message, cause, errorData) {
    super(message);
    this.name = this.constructor.name;
    this.cause = cause;
    this.errorData = errorData;
  }
  /**
   * Create DurableOperationError from ErrorObject (for reconstruction during replay)
   */
  static fromErrorObject(errorObject) {
    const cause = new Error(errorObject.ErrorMessage);
    cause.name = errorObject.ErrorType || "Error";
    cause.stack = errorObject.StackTrace?.join("\n");
    switch (errorObject.ErrorType) {
      case "StepError":
        return new StepError(errorObject.ErrorMessage || "Step failed", cause, errorObject.ErrorData);
      case "CallbackError":
        return new CallbackError(errorObject.ErrorMessage || "Callback failed", cause, errorObject.ErrorData);
      case "InvokeError":
        return new InvokeError(errorObject.ErrorMessage || "Invoke failed", cause, errorObject.ErrorData);
      case "ChildContextError":
        return new ChildContextError(errorObject.ErrorMessage || "Child context failed", cause, errorObject.ErrorData);
      case "WaitForConditionError":
        return new WaitForConditionError(errorObject.ErrorMessage || "Wait for condition failed", cause, errorObject.ErrorData);
      default:
        return new StepError(errorObject.ErrorMessage || "Unknown error", cause, errorObject.ErrorData);
    }
  }
  /**
   * Convert to ErrorObject for serialization
   */
  toErrorObject() {
    return {
      ErrorType: this.errorType,
      ErrorMessage: this.message,
      ErrorData: this.errorData,
      StackTrace: void 0
    };
  }
};
var StepError = class extends DurableOperationError {
  errorType = "StepError";
  constructor(message, cause, errorData) {
    super(message || "Step failed", cause, errorData);
  }
};
var CallbackError = class extends DurableOperationError {
  errorType = "CallbackError";
  constructor(message, cause, errorData) {
    super(message || "Callback failed", cause, errorData);
  }
};
var InvokeError = class extends DurableOperationError {
  errorType = "InvokeError";
  constructor(message, cause, errorData) {
    super(message || "Invoke failed", cause, errorData);
  }
};
var ChildContextError = class extends DurableOperationError {
  errorType = "ChildContextError";
  constructor(message, cause, errorData) {
    super(message || "Child context failed", cause, errorData);
  }
};
var WaitForConditionError = class extends DurableOperationError {
  errorType = "WaitForConditionError";
  constructor(message, cause, errorData) {
    super(message || "Wait for condition failed", cause, errorData);
  }
};
var defaultSerdes = {
  serialize: async (value, _context) => value !== void 0 ? JSON.stringify(value) : void 0,
  deserialize: async (data, _context) => data !== void 0 ? JSON.parse(data) : void 0
};
var UnrecoverableError = class extends Error {
  originalError;
  isUnrecoverable = true;
  constructor(message, originalError) {
    super(message);
    this.originalError = originalError;
    this.name = this.constructor.name;
    if (originalError?.stack) {
      this.stack = `${this.stack}
Caused by: ${originalError.stack}`;
    }
  }
};
var UnrecoverableExecutionError = class extends UnrecoverableError {
  isUnrecoverableExecution = true;
  constructor(message, originalError) {
    super(`[Unrecoverable Execution] ${message}`, originalError);
  }
};
var UnrecoverableInvocationError = class extends UnrecoverableError {
  isUnrecoverableInvocation = true;
  constructor(message, originalError) {
    super(`[Unrecoverable Invocation] ${message}`, originalError);
  }
};
function isUnrecoverableError(error) {
  return error instanceof Error && "isUnrecoverable" in error && error.isUnrecoverable === true;
}
function isUnrecoverableInvocationError(error) {
  return error instanceof Error && "isUnrecoverableInvocation" in error && error.isUnrecoverableInvocation === true;
}
var SerdesFailedError = class extends UnrecoverableInvocationError {
  terminationReason = TerminationReason.SERDES_FAILED;
  constructor(message, originalError) {
    super(message || "Serdes operation failed", originalError);
  }
};
async function safeSerialize(serdes, value, stepId, stepName, terminationManager, durableExecutionArn) {
  try {
    const context = {
      entityId: stepId,
      durableExecutionArn
    };
    return await serdes.serialize(value, context);
  } catch (error) {
    const message = `Serialization failed for step ${stepName ? `"${stepName}" ` : ""}(${stepId}): ${error instanceof Error ? error.message : "Unknown serialization error"}`;
    log("\u{1F4A5}", "Serialization failed - terminating execution:", {
      stepId,
      stepName,
      error: error instanceof Error ? error.message : String(error)
    });
    terminationManager.terminate({
      reason: TerminationReason.SERDES_FAILED,
      message
    });
    return new Promise(() => {
    });
  }
}
async function safeDeserialize(serdes, data, stepId, stepName, terminationManager, durableExecutionArn) {
  try {
    const context = {
      entityId: stepId,
      durableExecutionArn
    };
    return await serdes.deserialize(data, context);
  } catch (error) {
    const message = `Deserialization failed for step ${stepName ? `"${stepName}" ` : ""}(${stepId}): ${error instanceof Error ? error.message : "Unknown deserialization error"}`;
    log("\u{1F4A5}", "Deserialization failed - terminating execution:", {
      stepId,
      stepName,
      error: error instanceof Error ? error.message : String(error)
    });
    terminationManager.terminate({
      reason: TerminationReason.SERDES_FAILED,
      message
    });
    return new Promise(() => {
    });
  }
}
function isErrorLike(obj) {
  return obj instanceof Error || obj != null && typeof obj === "object" && "message" in obj && "name" in obj;
}
function createErrorObjectFromError(error, data) {
  if (error instanceof DurableOperationError) {
    const errorObject = error.toErrorObject();
    return errorObject;
  }
  if (isErrorLike(error)) {
    return {
      ErrorData: data,
      ErrorMessage: error.message,
      ErrorType: error.name,
      StackTrace: void 0
    };
  }
  return {
    ErrorData: data,
    ErrorMessage: "Unknown error"
  };
}
var CheckpointUnrecoverableInvocationError = class extends UnrecoverableInvocationError {
  terminationReason = TerminationReason.CHECKPOINT_FAILED;
  constructor(message, originalError) {
    super(message || "Checkpoint operation failed", originalError);
  }
};
var CheckpointUnrecoverableExecutionError = class extends UnrecoverableExecutionError {
  terminationReason = TerminationReason.CHECKPOINT_FAILED;
  constructor(message, originalError) {
    super(message || "Checkpoint operation failed", originalError);
  }
};
var STEP_DATA_UPDATED_EVENT = "stepDataUpdated";
var CheckpointManager = class _CheckpointManager {
  durableExecutionArn;
  stepData;
  storage;
  terminationManager;
  activeOperationsTracker;
  stepDataEmitter;
  logger;
  pendingCompletions;
  queue = [];
  isProcessing = false;
  currentTaskToken;
  forceCheckpointPromises = [];
  queueCompletionResolver = null;
  queueCompletionTimeout = null;
  MAX_PAYLOAD_SIZE = 750 * 1024;
  // 750KB in bytes
  isTerminating = false;
  static textEncoder = new TextEncoder();
  constructor(durableExecutionArn, stepData, storage, terminationManager, activeOperationsTracker, initialTaskToken, stepDataEmitter, logger, pendingCompletions) {
    this.durableExecutionArn = durableExecutionArn;
    this.stepData = stepData;
    this.storage = storage;
    this.terminationManager = terminationManager;
    this.activeOperationsTracker = activeOperationsTracker;
    this.stepDataEmitter = stepDataEmitter;
    this.logger = logger;
    this.pendingCompletions = pendingCompletions;
    this.currentTaskToken = initialTaskToken;
  }
  setTerminating() {
    this.isTerminating = true;
    log("\u{1F6D1}", "Checkpoint manager marked as terminating");
  }
  /**
   * Checks if a step ID or any of its ancestors has a pending completion
   */
  hasPendingAncestorCompletion(stepId) {
    let currentHashedId = hashId(stepId);
    while (currentHashedId) {
      if (this.pendingCompletions.has(currentHashedId)) {
        return true;
      }
      const operation = this.stepData[currentHashedId];
      currentHashedId = operation?.ParentId;
    }
    return false;
  }
  async forceCheckpoint() {
    if (this.isTerminating) {
      log("\u26A0\uFE0F", "Force checkpoint skipped - termination in progress");
      return new Promise(() => {
      });
    }
    return new Promise((resolve, reject) => {
      this.forceCheckpointPromises.push({ resolve, reject });
      if (!this.isProcessing) {
        setImmediate(() => {
          this.processQueue();
        });
      }
    });
  }
  async waitForQueueCompletion() {
    if (this.queue.length === 0 && !this.isProcessing) {
      return;
    }
    return new Promise((resolve, reject) => {
      this.queueCompletionResolver = resolve;
      this.queueCompletionTimeout = setTimeout(() => {
        this.queueCompletionResolver = null;
        this.queueCompletionTimeout = null;
        this.clearQueue();
        reject(new Error("Timeout waiting for checkpoint queue completion"));
      }, 3e3);
    });
  }
  clearQueue() {
    this.queue = [];
    this.forceCheckpointPromises = [];
    this.notifyQueueCompletion();
  }
  // Alias for backward compatibility with Checkpoint interface
  async force() {
    return this.forceCheckpoint();
  }
  async checkpoint(stepId, data) {
    if (this.isTerminating) {
      log("\u26A0\uFE0F", "Checkpoint skipped - termination in progress:", { stepId });
      return new Promise(() => {
      });
    }
    if (this.activeOperationsTracker) {
      this.activeOperationsTracker.increment();
    }
    return new Promise((resolve, reject) => {
      if (data.Action === import_client_lambda.OperationAction.SUCCEED || data.Action === import_client_lambda.OperationAction.FAIL) {
        this.pendingCompletions.add(stepId);
      }
      const queuedItem = {
        stepId,
        data,
        resolve: () => {
          if (this.activeOperationsTracker) {
            this.activeOperationsTracker.decrement();
          }
          resolve();
        },
        reject: (error) => {
          if (this.activeOperationsTracker) {
            this.activeOperationsTracker.decrement();
          }
          reject(error);
        }
      };
      this.queue.push(queuedItem);
      log("\u{1F4E5}", "Checkpoint queued:", {
        stepId,
        queueLength: this.queue.length,
        isProcessing: this.isProcessing
      });
      if (!this.isProcessing) {
        setImmediate(() => {
          this.processQueue();
        });
      }
    });
  }
  hasFinishedAncestor(parentId) {
    if (!parentId) {
      return false;
    }
    let currentHashedId = hashId(parentId);
    while (currentHashedId) {
      const parentOperation = this.stepData[currentHashedId];
      if (parentOperation?.Status === import_client_lambda.OperationStatus.SUCCEEDED || parentOperation?.Status === import_client_lambda.OperationStatus.FAILED) {
        return true;
      }
      currentHashedId = parentOperation?.ParentId;
    }
    return false;
  }
  classifyCheckpointError(error) {
    const originalError = error instanceof Error ? error : new Error(String(error));
    const awsError = error;
    const statusCode = awsError.$metadata?.httpStatusCode;
    const errorName = awsError.name;
    const errorMessage = awsError.message || originalError.message;
    log("\u{1F50D}", "Classifying checkpoint error:", {
      statusCode,
      errorName,
      errorMessage
    });
    if (statusCode && statusCode >= 400 && statusCode < 500 && errorName === "InvalidParameterValueException" && errorMessage.startsWith("Invalid Checkpoint Token")) {
      return new CheckpointUnrecoverableInvocationError(`Checkpoint failed: ${errorMessage}`, originalError);
    }
    if (statusCode && statusCode >= 400 && statusCode < 500 && statusCode !== 429) {
      return new CheckpointUnrecoverableExecutionError(`Checkpoint failed: ${errorMessage}`, originalError);
    }
    return new CheckpointUnrecoverableInvocationError(`Checkpoint failed: ${errorMessage}`, originalError);
  }
  async processQueue() {
    if (this.isProcessing) {
      return;
    }
    const hasQueuedItems = this.queue.length > 0;
    const hasForceRequests = this.forceCheckpointPromises.length > 0;
    if (!hasQueuedItems && !hasForceRequests) {
      return;
    }
    this.isProcessing = true;
    const batch = [];
    let skippedCount = 0;
    const baseSize = this.currentTaskToken.length + 100;
    let currentSize = baseSize;
    while (this.queue.length > 0) {
      const nextItem = this.queue[0];
      const itemSize = _CheckpointManager.textEncoder.encode(JSON.stringify(nextItem)).length;
      if (currentSize + itemSize > this.MAX_PAYLOAD_SIZE && batch.length > 0) {
        break;
      }
      this.queue.shift();
      if (this.hasFinishedAncestor(nextItem.data.ParentId)) {
        log("\u26A0\uFE0F", "Checkpoint skipped - ancestor finished:", {
          stepId: nextItem.stepId,
          parentId: nextItem.data.ParentId
        });
        skippedCount++;
        continue;
      }
      batch.push(nextItem);
      currentSize += itemSize;
    }
    log("\u{1F504}", "Processing checkpoint batch:", {
      batchSize: batch.length,
      remainingInQueue: this.queue.length,
      estimatedSize: currentSize,
      maxSize: this.MAX_PAYLOAD_SIZE
    });
    try {
      if (batch.length > 0 || this.forceCheckpointPromises.length > 0) {
        await this.processBatch(batch);
      }
      batch.forEach((item) => {
        if (item.data.Action === import_client_lambda.OperationAction.SUCCEED || item.data.Action === import_client_lambda.OperationAction.FAIL) {
          this.pendingCompletions.delete(item.stepId);
        }
        item.resolve();
      });
      const forcePromises = this.forceCheckpointPromises.splice(0);
      forcePromises.forEach((promise) => {
        promise.resolve();
      });
      log("\u2705", "Checkpoint batch processed successfully:", {
        batchSize: batch.length,
        skippedCount,
        forceRequests: forcePromises.length,
        newTaskToken: this.currentTaskToken
      });
    } catch (error) {
      log("\u274C", "Checkpoint batch failed:", {
        batchSize: batch.length,
        error
      });
      const checkpointError = this.classifyCheckpointError(error);
      this.clearQueue();
      this.terminationManager.terminate({
        reason: TerminationReason.CHECKPOINT_FAILED,
        message: checkpointError.message,
        error: checkpointError
      });
    } finally {
      this.isProcessing = false;
      if (this.queue.length > 0) {
        setImmediate(() => {
          this.processQueue();
        });
      } else {
        this.notifyQueueCompletion();
      }
    }
  }
  notifyQueueCompletion() {
    if (this.queueCompletionResolver) {
      if (this.queueCompletionTimeout) {
        clearTimeout(this.queueCompletionTimeout);
        this.queueCompletionTimeout = null;
      }
      this.queueCompletionResolver();
      this.queueCompletionResolver = null;
    }
  }
  async processBatch(batch) {
    const updates = batch.map((item) => {
      const hashedStepId = hashId(item.stepId);
      const update = {
        Type: item.data.Type || "STEP",
        Action: item.data.Action || "START",
        ...item.data,
        Id: hashedStepId,
        ...item.data.ParentId && { ParentId: hashId(item.data.ParentId) }
      };
      return update;
    });
    const checkpointData = {
      DurableExecutionArn: this.durableExecutionArn,
      CheckpointToken: this.currentTaskToken,
      Updates: updates
    };
    log("\u23FA\uFE0F", "Creating checkpoint batch:", {
      batchSize: updates.length,
      checkpointToken: this.currentTaskToken,
      updates: updates.map((u) => ({
        Id: u.Id,
        Action: u.Action,
        Type: u.Type
      }))
    });
    const response = await this.storage.checkpoint(checkpointData, this.logger);
    if (response.CheckpointToken) {
      this.currentTaskToken = response.CheckpointToken;
    }
    if (response.NewExecutionState?.Operations) {
      this.updateStepDataFromCheckpointResponse(response.NewExecutionState.Operations);
    }
  }
  updateStepDataFromCheckpointResponse(operations) {
    log("\u{1F504}", "Updating stepData from checkpoint response:", {
      operationCount: operations.length,
      operationIds: operations.map((op) => op.Id).filter(Boolean)
    });
    operations.forEach((operation) => {
      if (operation.Id) {
        this.stepData[operation.Id] = operation;
        log("\u{1F4DD}", "Updated stepData entry:", operation);
        this.stepDataEmitter.emit(STEP_DATA_UPDATED_EVENT, operation.Id);
      }
    });
    log("\u2705", "StepData update completed:", {
      totalStepDataEntries: Object.keys(this.stepData).length
    });
  }
  getQueueStatus() {
    return {
      queueLength: this.queue.length,
      isProcessing: this.isProcessing
    };
  }
};
async function waitBeforeContinue(options) {
  const { checkHasRunningOperations, checkStepStatus, checkTimer, scheduledEndTimestamp, stepId, context, hasRunningOperations, operationsEmitter, checkpoint, onAwaitedChange } = options;
  const promises = [];
  const timers = [];
  const cleanupFns = [];
  const cleanup = () => {
    timers.forEach((timer) => clearTimeout(timer));
    cleanupFns.forEach((fn) => fn());
  };
  if (checkTimer && scheduledEndTimestamp) {
    const timerPromise = new Promise((resolve) => {
      const timeLeft = Number(scheduledEndTimestamp) - Date.now();
      if (timeLeft > 0) {
        const timer = setTimeout(() => resolve({ reason: "timer", timerExpired: true }), timeLeft);
        timers.push(timer);
      } else {
        resolve({ reason: "timer", timerExpired: true });
      }
    });
    promises.push(timerPromise);
  }
  if (checkHasRunningOperations) {
    const operationsPromise = new Promise((resolve) => {
      if (!hasRunningOperations()) {
        resolve({ reason: "operations" });
      } else {
        const handler2 = () => {
          resolve({ reason: "operations" });
        };
        operationsEmitter.once(OPERATIONS_COMPLETE_EVENT, handler2);
        cleanupFns.push(() => operationsEmitter.off(OPERATIONS_COMPLETE_EVENT, handler2));
      }
    });
    promises.push(operationsPromise);
  }
  if (checkStepStatus) {
    const originalStatus = context.getStepData(stepId)?.Status;
    const hashedStepId = hashId(stepId);
    const stepStatusPromise = new Promise((resolve) => {
      const currentStatus = context.getStepData(stepId)?.Status;
      if (originalStatus !== currentStatus) {
        resolve({ reason: "status" });
      } else {
        const handler2 = (updatedStepId) => {
          if (updatedStepId === hashedStepId) {
            const newStatus = context.getStepData(stepId)?.Status;
            if (originalStatus !== newStatus) {
              resolve({ reason: "status" });
            }
          }
        };
        operationsEmitter.on(STEP_DATA_UPDATED_EVENT, handler2);
        cleanupFns.push(() => operationsEmitter.off(STEP_DATA_UPDATED_EVENT, handler2));
      }
    });
    promises.push(stepStatusPromise);
  }
  if (onAwaitedChange) {
    const awaitedChangePromise = new Promise((resolve) => {
      onAwaitedChange(() => {
        resolve({ reason: "status" });
      });
    });
    promises.push(awaitedChangePromise);
  }
  if (promises.length === 0) {
    return { reason: "timeout" };
  }
  const result = await Promise.race(promises);
  cleanup();
  if (result.reason === "timer" && result.timerExpired && checkpoint) {
    if (checkpoint.force) {
      await checkpoint.force();
    } else if (checkpoint.forceCheckpoint) {
      await checkpoint.forceCheckpoint();
    }
  }
  return result;
}
var NonDeterministicExecutionError = class extends UnrecoverableExecutionError {
  terminationReason = TerminationReason.CUSTOM;
  constructor(message) {
    super(message);
    this.name = "NonDeterministicExecutionError";
  }
};
var validateReplayConsistency = (stepId, currentOperation, checkpointData, context) => {
  if (!checkpointData || !checkpointData.Type) {
    return;
  }
  if (checkpointData.Type !== currentOperation.type) {
    const error = new NonDeterministicExecutionError(`Non-deterministic execution detected: Operation type mismatch for step "${stepId}". Expected type "${checkpointData.Type}", but got "${currentOperation.type}". This indicates non-deterministic control flow in your workflow code.`);
    terminateForUnrecoverableError(context, error, stepId);
  }
  if (checkpointData.Name !== currentOperation.name) {
    const error = new NonDeterministicExecutionError(`Non-deterministic execution detected: Operation name mismatch for step "${stepId}". Expected name "${checkpointData.Name ?? "undefined"}", but got "${currentOperation.name ?? "undefined"}". This indicates non-deterministic control flow in your workflow code.`);
    terminateForUnrecoverableError(context, error, stepId);
  }
  if (checkpointData.SubType !== currentOperation.subType) {
    const error = new NonDeterministicExecutionError(`Non-deterministic execution detected: Operation subtype mismatch for step "${stepId}". Expected subtype "${checkpointData.SubType}", but got "${currentOperation.subType}". This indicates non-deterministic control flow in your workflow code.`);
    terminateForUnrecoverableError(context, error, stepId);
  }
};
var CONTINUE_MAIN_LOOP$1 = Symbol("CONTINUE_MAIN_LOOP");
var waitForContinuation$1 = async (context, stepId, name, hasRunningOperations, getOperationsEmitter, checkpoint, onAwaitedChange) => {
  const stepData = context.getStepData(stepId);
  if (!hasRunningOperations()) {
    return terminate(context, TerminationReason.RETRY_SCHEDULED, `Retry scheduled for ${name || stepId}`);
  }
  await waitBeforeContinue({
    checkHasRunningOperations: true,
    checkStepStatus: true,
    checkTimer: true,
    scheduledEndTimestamp: stepData?.StepDetails?.NextAttemptTimestamp,
    stepId,
    context,
    hasRunningOperations,
    operationsEmitter: getOperationsEmitter(),
    checkpoint,
    onAwaitedChange
  });
};
var createStepHandler = (context, checkpoint, parentContext, createStepId, logger, addRunningOperation, removeRunningOperation, hasRunningOperations, getOperationsEmitter, parentId) => {
  return (nameOrFn, fnOrOptions, maybeOptions) => {
    let name;
    let fn;
    let options;
    if (typeof nameOrFn === "string" || nameOrFn === void 0) {
      name = nameOrFn;
      fn = fnOrOptions;
      options = maybeOptions;
    } else {
      fn = nameOrFn;
      options = fnOrOptions;
    }
    const stepId = createStepId();
    log("\u25B6\uFE0F", "Running step:", { stepId, name, options });
    let isAwaited = false;
    let waitingCallback;
    const setWaitingCallback = (cb) => {
      waitingCallback = cb;
    };
    const phase1Promise = (async () => {
      while (true) {
        try {
          const stepData = context.getStepData(stepId);
          validateReplayConsistency(stepId, {
            type: import_client_lambda.OperationType.STEP,
            name,
            subType: OperationSubType.STEP
          }, stepData, context);
          if (stepData?.Status === import_client_lambda.OperationStatus.SUCCEEDED) {
            return await handleCompletedStep(context, stepId, name, options?.serdes);
          }
          if (stepData?.Status === import_client_lambda.OperationStatus.FAILED) {
            return (async () => {
              if (stepData.StepDetails?.Error) {
                throw DurableOperationError.fromErrorObject(stepData.StepDetails.Error);
              } else {
                const errorMessage = stepData?.StepDetails?.Result;
                throw new StepError(errorMessage || "Unknown error");
              }
            })();
          }
          if (stepData?.Status === import_client_lambda.OperationStatus.PENDING) {
            await waitForContinuation$1(context, stepId, name, hasRunningOperations, getOperationsEmitter, checkpoint, isAwaited ? void 0 : setWaitingCallback);
            continue;
          }
          if (stepData?.Status === import_client_lambda.OperationStatus.STARTED) {
            const semantics = options?.semantics || StepSemantics.AtLeastOncePerRetry;
            if (semantics === StepSemantics.AtMostOncePerRetry) {
              log("\u26A0\uFE0F", "Step was interrupted during execution:", {
                stepId,
                name
              });
              const error = new StepInterruptedError(stepId, name);
              const currentAttempt = (stepData?.StepDetails?.Attempt || 0) + 1;
              let retryDecision;
              if (options?.retryStrategy !== void 0) {
                retryDecision = options.retryStrategy(error, currentAttempt);
              } else {
                retryDecision = retryPresets.default(error, currentAttempt);
              }
              log("\u26A0\uFE0F", "Should Retry Interrupted Step:", {
                stepId,
                name,
                currentAttempt,
                shouldRetry: retryDecision.shouldRetry,
                delayInSeconds: retryDecision.shouldRetry ? retryDecision.delay ? durationToSeconds(retryDecision.delay) : void 0 : void 0
              });
              if (!retryDecision.shouldRetry) {
                await checkpoint.checkpoint(stepId, {
                  Id: stepId,
                  ParentId: parentId,
                  Action: import_client_lambda.OperationAction.FAIL,
                  SubType: OperationSubType.STEP,
                  Type: import_client_lambda.OperationType.STEP,
                  Error: createErrorObjectFromError(error),
                  Name: name
                });
                const errorObject = createErrorObjectFromError(error);
                throw DurableOperationError.fromErrorObject(errorObject);
              } else {
                await checkpoint.checkpoint(stepId, {
                  Id: stepId,
                  ParentId: parentId,
                  Action: import_client_lambda.OperationAction.RETRY,
                  SubType: OperationSubType.STEP,
                  Type: import_client_lambda.OperationType.STEP,
                  Error: createErrorObjectFromError(error),
                  Name: name,
                  StepOptions: {
                    NextAttemptDelaySeconds: retryDecision.delay ? durationToSeconds(retryDecision.delay) : 1
                  }
                });
                await waitForContinuation$1(context, stepId, name, hasRunningOperations, getOperationsEmitter, checkpoint, isAwaited ? void 0 : setWaitingCallback);
                continue;
              }
            }
          }
          const result = await executeStep(context, checkpoint, stepId, name, fn, logger, addRunningOperation, removeRunningOperation, hasRunningOperations, getOperationsEmitter, parentId, options, isAwaited ? void 0 : setWaitingCallback);
          if (result === CONTINUE_MAIN_LOOP$1) {
            continue;
          }
          return result;
        } catch (error) {
          if (error instanceof DurableOperationError) {
            throw error;
          }
          throw new StepError(error instanceof Error ? error.message : "Step failed", error instanceof Error ? error : void 0);
        }
      }
    })();
    phase1Promise.catch(() => {
    });
    return new DurablePromise(async () => {
      isAwaited = true;
      if (waitingCallback) {
        waitingCallback();
      }
      return await phase1Promise;
    });
  };
};
var handleCompletedStep = async (context, stepId, stepName, serdes = defaultSerdes) => {
  log("\u23ED\uFE0F", "Step already finished, returning cached result:", { stepId });
  const stepData = context.getStepData(stepId);
  const result = stepData?.StepDetails?.Result;
  return await safeDeserialize(serdes, result, stepId, stepName, context.terminationManager, context.durableExecutionArn);
};
var executeStep = async (context, checkpoint, stepId, name, fn, logger, addRunningOperation, removeRunningOperation, hasRunningOperations, getOperationsEmitter, parentId, options, onAwaitedChange) => {
  const semantics = options?.semantics || StepSemantics.AtLeastOncePerRetry;
  const serdes = options?.serdes || defaultSerdes;
  const stepData = context.getStepData(stepId);
  if (stepData?.Status !== import_client_lambda.OperationStatus.STARTED) {
    if (semantics === StepSemantics.AtMostOncePerRetry) {
      await checkpoint.checkpoint(stepId, {
        Id: stepId,
        ParentId: parentId,
        Action: import_client_lambda.OperationAction.START,
        SubType: OperationSubType.STEP,
        Type: import_client_lambda.OperationType.STEP,
        Name: name
      });
    } else {
      checkpoint.checkpoint(stepId, {
        Id: stepId,
        ParentId: parentId,
        Action: import_client_lambda.OperationAction.START,
        SubType: OperationSubType.STEP,
        Type: import_client_lambda.OperationType.STEP,
        Name: name
      });
    }
  }
  try {
    const stepData2 = context.getStepData(stepId);
    const currentAttempt = stepData2?.StepDetails?.Attempt || 0;
    const stepContext = {
      logger
    };
    addRunningOperation(stepId);
    let result;
    try {
      result = await runWithContext(
        stepId,
        parentId,
        () => fn(stepContext),
        // The attempt that is running is the attempt from the step data (previous step attempt) + 1
        currentAttempt + 1,
        // Alwasy in execution mode when running step operations
        DurableExecutionMode.ExecutionMode
      );
    } finally {
      removeRunningOperation(stepId);
    }
    const serializedResult = await safeSerialize(serdes, result, stepId, name, context.terminationManager, context.durableExecutionArn);
    await checkpoint.checkpoint(stepId, {
      Id: stepId,
      ParentId: parentId,
      Action: import_client_lambda.OperationAction.SUCCEED,
      SubType: OperationSubType.STEP,
      Type: import_client_lambda.OperationType.STEP,
      Payload: serializedResult,
      Name: name
    });
    log("\u2705", "Step completed successfully:", {
      stepId,
      name,
      result,
      semantics
    });
    return await safeDeserialize(serdes, serializedResult, stepId, name, context.terminationManager, context.durableExecutionArn);
  } catch (error) {
    log("\u274C", "Step failed:", {
      stepId,
      name,
      error,
      semantics
    });
    if (isUnrecoverableError(error)) {
      log("\u{1F4A5}", "Unrecoverable error detected:", {
        stepId,
        name,
        error: error.message
      });
      return terminateForUnrecoverableError(context, error, name || stepId);
    }
    const stepData2 = context.getStepData(stepId);
    const currentAttempt = (stepData2?.StepDetails?.Attempt || 0) + 1;
    let retryDecision;
    if (options?.retryStrategy !== void 0) {
      retryDecision = options.retryStrategy(error instanceof Error ? error : new Error("Unknown Error"), currentAttempt);
    } else {
      retryDecision = retryPresets.default(error instanceof Error ? error : new Error("Unknown Error"), currentAttempt);
    }
    log("\u26A0\uFE0F", "Should Retry:", {
      stepId,
      name,
      currentAttempt,
      shouldRetry: retryDecision.shouldRetry,
      delayInSeconds: retryDecision.shouldRetry ? retryDecision.delay ? durationToSeconds(retryDecision.delay) : void 0 : void 0,
      semantics
    });
    if (!retryDecision.shouldRetry) {
      await checkpoint.checkpoint(stepId, {
        Id: stepId,
        ParentId: parentId,
        Action: import_client_lambda.OperationAction.FAIL,
        SubType: OperationSubType.STEP,
        Type: import_client_lambda.OperationType.STEP,
        Error: createErrorObjectFromError(error),
        Name: name
      });
      const errorObject = createErrorObjectFromError(error);
      throw DurableOperationError.fromErrorObject(errorObject);
    } else {
      await checkpoint.checkpoint(stepId, {
        Id: stepId,
        ParentId: parentId,
        Action: import_client_lambda.OperationAction.RETRY,
        SubType: OperationSubType.STEP,
        Type: import_client_lambda.OperationType.STEP,
        Error: createErrorObjectFromError(error),
        Name: name,
        StepOptions: {
          NextAttemptDelaySeconds: retryDecision.delay ? durationToSeconds(retryDecision.delay) : 1
        }
      });
      await waitForContinuation$1(context, stepId, name, hasRunningOperations, getOperationsEmitter, checkpoint, onAwaitedChange);
      return CONTINUE_MAIN_LOOP$1;
    }
  }
};
var createInvokeHandler = (context, checkpoint, createStepId, hasRunningOperations, getOperationsEmitter, parentId, checkAndUpdateReplayMode) => {
  function invokeHandler(nameOrFuncId, funcIdOrInput, inputOrConfig, maybeConfig) {
    const isNameFirst = typeof funcIdOrInput === "string";
    const name = isNameFirst ? nameOrFuncId : void 0;
    const funcId = isNameFirst ? funcIdOrInput : nameOrFuncId;
    const input = isNameFirst ? inputOrConfig : funcIdOrInput;
    const config = isNameFirst ? maybeConfig : inputOrConfig;
    const stepId = createStepId();
    const startInvokeOperation = async () => {
      log("\u{1F517}", `Invoke ${name || funcId} (${stepId}) - phase 1`);
      const initialStepData = context.getStepData(stepId);
      validateReplayConsistency(stepId, {
        type: import_client_lambda.OperationType.CHAINED_INVOKE,
        name,
        subType: OperationSubType.CHAINED_INVOKE
      }, initialStepData, context);
      if (initialStepData) {
        log("\u23F8\uFE0F", `Invoke ${name || funcId} already exists (phase 1)`);
        return;
      }
      const serializedPayload = await safeSerialize(config?.payloadSerdes || defaultSerdes, input, stepId, name, context.terminationManager, context.durableExecutionArn);
      await checkpoint.checkpoint(stepId, {
        Id: stepId,
        ParentId: parentId,
        Action: import_client_lambda.OperationAction.START,
        SubType: OperationSubType.CHAINED_INVOKE,
        Type: import_client_lambda.OperationType.CHAINED_INVOKE,
        Name: name,
        Payload: serializedPayload,
        ChainedInvokeOptions: {
          FunctionName: funcId
        }
      });
      log("\u{1F680}", `Invoke ${name || funcId} started (phase 1)`);
    };
    const continueInvokeOperation = async () => {
      log("\u{1F517}", `Invoke ${name || funcId} (${stepId}) - phase 2`);
      while (true) {
        const stepData = context.getStepData(stepId);
        if (stepData?.Status === import_client_lambda.OperationStatus.SUCCEEDED) {
          const invokeDetails = stepData.ChainedInvokeDetails;
          checkAndUpdateReplayMode?.();
          return await safeDeserialize(config?.resultSerdes || defaultSerdes, invokeDetails?.Result, stepId, name, context.terminationManager, context.durableExecutionArn);
        }
        if (stepData?.Status === import_client_lambda.OperationStatus.FAILED || stepData?.Status === import_client_lambda.OperationStatus.TIMED_OUT || stepData?.Status === import_client_lambda.OperationStatus.STOPPED) {
          const invokeDetails = stepData.ChainedInvokeDetails;
          return (async () => {
            if (invokeDetails?.Error) {
              throw new InvokeError(invokeDetails.Error.ErrorMessage || "Invoke failed", invokeDetails.Error.ErrorMessage ? new Error(invokeDetails.Error.ErrorMessage) : void 0, invokeDetails.Error.ErrorData);
            } else {
              throw new InvokeError("Invoke failed");
            }
          })();
        }
        if (stepData?.Status === import_client_lambda.OperationStatus.STARTED) {
          if (hasRunningOperations()) {
            log("\u23F3", `Invoke ${name || funcId} still in progress, waiting for other operations`);
            await waitBeforeContinue({
              checkHasRunningOperations: true,
              checkStepStatus: true,
              checkTimer: false,
              stepId,
              context,
              hasRunningOperations,
              operationsEmitter: getOperationsEmitter()
            });
            continue;
          }
          log("\u23F3", `Invoke ${name || funcId} still in progress, terminating`);
          return terminate(context, TerminationReason.OPERATION_TERMINATED, stepId);
        }
        if (stepData && stepData.Status !== void 0) {
          throw new InvokeError(`Unexpected operation status: ${stepData.Status}`);
        }
        throw new InvokeError("No step data found in phase 2 - this should not happen");
      }
    };
    const startInvokePromise = startInvokeOperation().then(() => {
      log("\u2705", "Invoke phase 1 complete:", { stepId, name: name || funcId });
    }).catch((error) => {
      log("\u274C", "Invoke phase 1 error:", { stepId, error: error.message });
      throw error;
    });
    startInvokePromise.catch(() => {
    });
    return new DurablePromise(async () => {
      await startInvokePromise;
      return await continueInvokeOperation();
    });
  }
  return invokeHandler;
};
var CHECKPOINT_SIZE_LIMIT = 256 * 1024;
var determineChildReplayMode = (context, stepId) => {
  const stepData = context.getStepData(stepId);
  if (!stepData) {
    return DurableExecutionMode.ExecutionMode;
  }
  if (stepData.Status === import_client_lambda.OperationStatus.SUCCEEDED && stepData.ContextDetails?.ReplayChildren) {
    return DurableExecutionMode.ReplaySucceededContext;
  }
  if (stepData.Status === import_client_lambda.OperationStatus.SUCCEEDED || stepData.Status === import_client_lambda.OperationStatus.FAILED) {
    return DurableExecutionMode.ReplayMode;
  }
  return DurableExecutionMode.ExecutionMode;
};
var createRunInChildContextHandler = (context, checkpoint, parentContext, createStepId, getParentLogger, createChildContext, parentId) => {
  return (nameOrFn, fnOrOptions, maybeOptions) => {
    let name;
    let fn;
    let options;
    if (typeof nameOrFn === "string" || nameOrFn === void 0) {
      name = nameOrFn;
      fn = fnOrOptions;
      options = maybeOptions;
    } else {
      fn = nameOrFn;
      options = fnOrOptions;
    }
    const entityId = createStepId();
    log("\u{1F504}", "Running child context:", {
      entityId,
      name
    });
    const stepData = context.getStepData(entityId);
    validateReplayConsistency(entityId, {
      type: import_client_lambda.OperationType.CONTEXT,
      name,
      subType: options?.subType || OperationSubType.RUN_IN_CHILD_CONTEXT
    }, stepData, context);
    let phase1Result;
    let phase1Error;
    const phase1Promise = (async () => {
      const currentStepData = context.getStepData(entityId);
      if (currentStepData?.Status === import_client_lambda.OperationStatus.SUCCEEDED || currentStepData?.Status === import_client_lambda.OperationStatus.FAILED) {
        return handleCompletedChildContext(context, parentContext, entityId, name, fn, options, getParentLogger, createChildContext);
      }
      return executeChildContext(context, checkpoint, parentContext, entityId, name, fn, options, getParentLogger, createChildContext, parentId);
    })().then((result) => {
      phase1Result = result;
    }).catch((error) => {
      phase1Error = error;
    });
    return new DurablePromise(async () => {
      await phase1Promise;
      if (phase1Error !== void 0) {
        throw phase1Error;
      }
      return phase1Result;
    });
  };
};
var handleCompletedChildContext = async (context, parentContext, entityId, stepName, fn, options, getParentLogger, createChildContext) => {
  const serdes = options?.serdes || defaultSerdes;
  const stepData = context.getStepData(entityId);
  const result = stepData?.ContextDetails?.Result;
  if (stepData?.Status === import_client_lambda.OperationStatus.FAILED) {
    if (stepData.ContextDetails?.Error) {
      const originalError = DurableOperationError.fromErrorObject(stepData.ContextDetails.Error);
      throw new ChildContextError(originalError.message, originalError);
    } else {
      throw new ChildContextError("Child context failed");
    }
  }
  if (stepData?.ContextDetails?.ReplayChildren) {
    log("\u{1F504}", "ReplayChildren mode: Re-executing child context due to large payload:", { entityId, stepName });
    const durableChildContext = createChildContext(context, parentContext, DurableExecutionMode.ReplaySucceededContext, getParentLogger(), entityId, void 0, entityId);
    return await runWithContext(entityId, entityId, () => fn(durableChildContext));
  }
  log("\u23ED\uFE0F", "Child context already finished, returning cached result:", {
    entityId
  });
  return await safeDeserialize(serdes, result, entityId, stepName, context.terminationManager, context.durableExecutionArn);
};
var executeChildContext = async (context, checkpoint, parentContext, entityId, name, fn, options, getParentLogger, createChildContext, parentId) => {
  const serdes = options?.serdes || defaultSerdes;
  if (context.getStepData(entityId) === void 0) {
    const subType = options?.subType || OperationSubType.RUN_IN_CHILD_CONTEXT;
    checkpoint.checkpoint(entityId, {
      Id: entityId,
      ParentId: parentId,
      Action: import_client_lambda.OperationAction.START,
      SubType: subType,
      Type: import_client_lambda.OperationType.CONTEXT,
      Name: name
    });
  }
  const childReplayMode = determineChildReplayMode(context, entityId);
  const durableChildContext = createChildContext(context, parentContext, childReplayMode, getParentLogger(), entityId, void 0, entityId);
  try {
    const result = await runWithContext(entityId, parentId, () => fn(durableChildContext), void 0, childReplayMode);
    const serializedResult = await safeSerialize(serdes, result, entityId, name, context.terminationManager, context.durableExecutionArn);
    let payloadToCheckpoint = serializedResult;
    let replayChildren = false;
    if (serializedResult && Buffer.byteLength(serializedResult, "utf8") > CHECKPOINT_SIZE_LIMIT) {
      replayChildren = true;
      if (options?.summaryGenerator) {
        payloadToCheckpoint = options.summaryGenerator(result);
      } else {
        payloadToCheckpoint = "";
      }
      log("\u{1F4E6}", "Large payload detected, using ReplayChildren mode:", {
        entityId,
        name,
        payloadSize: Buffer.byteLength(serializedResult, "utf8"),
        limit: CHECKPOINT_SIZE_LIMIT
      });
    }
    const subType = options?.subType || OperationSubType.RUN_IN_CHILD_CONTEXT;
    await checkpoint.checkpoint(entityId, {
      Id: entityId,
      ParentId: parentId,
      Action: import_client_lambda.OperationAction.SUCCEED,
      SubType: subType,
      Type: import_client_lambda.OperationType.CONTEXT,
      Payload: payloadToCheckpoint,
      ContextOptions: replayChildren ? { ReplayChildren: true } : void 0,
      Name: name
    });
    log("\u2705", "Child context completed successfully:", {
      entityId,
      name
    });
    return result;
  } catch (error) {
    log("\u274C", "Child context failed:", {
      entityId,
      name,
      error
    });
    const subType = options?.subType || OperationSubType.RUN_IN_CHILD_CONTEXT;
    await checkpoint.checkpoint(entityId, {
      Id: entityId,
      ParentId: parentId,
      Action: import_client_lambda.OperationAction.FAIL,
      SubType: subType,
      Type: import_client_lambda.OperationType.CONTEXT,
      Error: createErrorObjectFromError(error),
      Name: name
    });
    const errorObject = createErrorObjectFromError(error);
    const reconstructedError = DurableOperationError.fromErrorObject(errorObject);
    throw new ChildContextError(reconstructedError.message, reconstructedError);
  }
};
var createWaitHandler = (context, checkpoint, createStepId, hasRunningOperations, getOperationsEmitter, parentId, checkAndUpdateReplayMode) => {
  function waitHandler(nameOrDuration, duration) {
    const isNameFirst = typeof nameOrDuration === "string";
    const actualName = isNameFirst ? nameOrDuration : void 0;
    const actualDuration = isNameFirst ? duration : nameOrDuration;
    const actualSeconds = durationToSeconds(actualDuration);
    const stepId = createStepId();
    const executeWaitLogic = async (canTerminate) => {
      log("\u23F2\uFE0F", `Wait executing (${canTerminate ? "phase 2" : "phase 1"}):`, {
        stepId,
        name: actualName,
        duration: actualDuration,
        seconds: actualSeconds
      });
      let stepData = context.getStepData(stepId);
      validateReplayConsistency(stepId, {
        type: import_client_lambda.OperationType.WAIT,
        name: actualName,
        subType: OperationSubType.WAIT
      }, stepData, context);
      while (true) {
        stepData = context.getStepData(stepId);
        if (stepData?.Status === import_client_lambda.OperationStatus.SUCCEEDED) {
          log("\u23ED\uFE0F", "Wait already completed:", { stepId });
          checkAndUpdateReplayMode?.();
          return;
        }
        if (!stepData) {
          await checkpoint.checkpoint(stepId, {
            Id: stepId,
            ParentId: parentId,
            Action: import_client_lambda.OperationAction.START,
            SubType: OperationSubType.WAIT,
            Type: import_client_lambda.OperationType.WAIT,
            Name: actualName,
            WaitOptions: {
              WaitSeconds: actualSeconds
            }
          });
        }
        stepData = context.getStepData(stepId);
        if (!hasRunningOperations()) {
          if (canTerminate) {
            return terminate(context, TerminationReason.WAIT_SCHEDULED, `Operation ${actualName || stepId} scheduled to wait`);
          } else {
            log("\u23F8\uFE0F", "Wait ready but not terminating (phase 1):", { stepId });
            return;
          }
        }
        await waitBeforeContinue({
          checkHasRunningOperations: true,
          checkStepStatus: true,
          checkTimer: true,
          scheduledEndTimestamp: stepData?.WaitDetails?.ScheduledEndTimestamp,
          stepId,
          context,
          hasRunningOperations,
          operationsEmitter: getOperationsEmitter(),
          checkpoint
        });
      }
    };
    const phase1Promise = executeWaitLogic(false).then(() => {
      log("\u2705", "Wait phase 1 complete:", { stepId, name: actualName });
    });
    phase1Promise.catch(() => {
    });
    return new DurablePromise(async () => {
      await phase1Promise;
      await executeWaitLogic(true);
    });
  }
  return waitHandler;
};
var CONTINUE_MAIN_LOOP = Symbol("CONTINUE_MAIN_LOOP");
var waitForContinuation = async (context, stepId, name, hasRunningOperations, checkpoint, operationsEmitter, onAwaitedChange) => {
  const stepData = context.getStepData(stepId);
  if (!hasRunningOperations()) {
    return terminate(context, TerminationReason.RETRY_SCHEDULED, `Retry scheduled for ${name || stepId}`);
  }
  await waitBeforeContinue({
    checkHasRunningOperations: true,
    checkStepStatus: true,
    checkTimer: true,
    scheduledEndTimestamp: stepData?.StepDetails?.NextAttemptTimestamp,
    stepId,
    context,
    hasRunningOperations,
    operationsEmitter,
    checkpoint,
    onAwaitedChange
  });
};
var createWaitForConditionHandler = (context, checkpoint, createStepId, logger, addRunningOperation, removeRunningOperation, hasRunningOperations, getOperationsEmitter, parentId) => {
  return (nameOrCheck, checkOrConfig, maybeConfig) => {
    let isAwaited = false;
    let waitingCallback;
    const setWaitingCallback = (cb) => {
      waitingCallback = cb;
    };
    const phase1Promise = (async () => {
      let name;
      let check;
      let config;
      if (typeof nameOrCheck === "string" || nameOrCheck === void 0) {
        name = nameOrCheck;
        check = checkOrConfig;
        config = maybeConfig;
      } else {
        check = nameOrCheck;
        config = checkOrConfig;
      }
      if (!config || !config.waitStrategy || config.initialState === void 0) {
        throw new Error("waitForCondition requires config with waitStrategy and initialState");
      }
      const stepId = createStepId();
      log("\u{1F504}", "Running waitForCondition:", {
        stepId,
        name,
        config
      });
      while (true) {
        try {
          const stepData = context.getStepData(stepId);
          if (stepData?.Status === import_client_lambda.OperationStatus.SUCCEEDED) {
            return await handleCompletedWaitForCondition(context, stepId, name, config.serdes);
          }
          if (stepData?.Status === import_client_lambda.OperationStatus.FAILED) {
            return (async () => {
              if (stepData.StepDetails?.Error) {
                throw DurableOperationError.fromErrorObject(stepData.StepDetails.Error);
              } else {
                const errorMessage = stepData?.StepDetails?.Result;
                throw new WaitForConditionError(errorMessage || "waitForCondition failed");
              }
            })();
          }
          if (stepData?.Status === import_client_lambda.OperationStatus.PENDING) {
            await waitForContinuation(context, stepId, name, hasRunningOperations, checkpoint, getOperationsEmitter(), isAwaited ? void 0 : setWaitingCallback);
            continue;
          }
          const result = await executeWaitForCondition(context, checkpoint, stepId, name, check, config, logger, addRunningOperation, removeRunningOperation, hasRunningOperations, getOperationsEmitter, parentId, isAwaited ? void 0 : setWaitingCallback);
          if (result === CONTINUE_MAIN_LOOP) {
            continue;
          }
          return result;
        } catch (error) {
          throw error;
        }
      }
    })();
    phase1Promise.catch(() => {
    });
    return new DurablePromise(async () => {
      isAwaited = true;
      if (waitingCallback) {
        waitingCallback();
      }
      return await phase1Promise;
    });
  };
};
var handleCompletedWaitForCondition = async (context, stepId, stepName, serdes = defaultSerdes) => {
  log("\u23ED\uFE0F", "waitForCondition already finished, returning cached result:", {
    stepId
  });
  const stepData = context.getStepData(stepId);
  const result = stepData?.StepDetails?.Result;
  return await safeDeserialize(serdes, result, stepId, stepName, context.terminationManager, context.durableExecutionArn);
};
var executeWaitForCondition = async (context, checkpoint, stepId, name, check, config, logger, addRunningOperation, removeRunningOperation, hasRunningOperations, getOperationsEmitter, parentId, onAwaitedChange) => {
  const serdes = config.serdes || defaultSerdes;
  let currentState;
  const existingOperation = context.getStepData(stepId);
  if (existingOperation?.Status === import_client_lambda.OperationStatus.STARTED || existingOperation?.Status === import_client_lambda.OperationStatus.READY) {
    const checkpointData = existingOperation.StepDetails?.Result;
    if (checkpointData) {
      try {
        const serdesContext = {
          entityId: stepId,
          durableExecutionArn: context.durableExecutionArn
        };
        currentState = await serdes.deserialize(checkpointData, serdesContext);
      } catch (error) {
        log("\u26A0\uFE0F", "Failed to deserialize checkpoint data, using initial state:", {
          stepId,
          name,
          error
        });
        currentState = config.initialState;
      }
    } else {
      currentState = config.initialState;
    }
  } else {
    currentState = config.initialState;
  }
  const currentAttempt = existingOperation?.StepDetails?.Attempt || 1;
  const stepData = context.getStepData(stepId);
  if (stepData?.Status !== import_client_lambda.OperationStatus.STARTED) {
    checkpoint.checkpoint(stepId, {
      Id: stepId,
      ParentId: parentId,
      Action: import_client_lambda.OperationAction.START,
      SubType: OperationSubType.WAIT_FOR_CONDITION,
      Type: import_client_lambda.OperationType.STEP,
      Name: name
    });
  }
  try {
    const waitForConditionContext = {
      logger
    };
    addRunningOperation(stepId);
    let newState;
    try {
      newState = await runWithContext(stepId, parentId, () => check(currentState, waitForConditionContext), currentAttempt + 1, DurableExecutionMode.ExecutionMode);
    } finally {
      removeRunningOperation(stepId);
    }
    const serializedState = await safeSerialize(serdes, newState, stepId, name, context.terminationManager, context.durableExecutionArn);
    const deserializedState = await safeDeserialize(serdes, serializedState, stepId, name, context.terminationManager, context.durableExecutionArn);
    const decision = config.waitStrategy(deserializedState, currentAttempt);
    log("\u{1F50D}", "waitForCondition check completed:", {
      stepId,
      name,
      currentAttempt,
      shouldContinue: decision.shouldContinue,
      delayInSeconds: decision.shouldContinue ? durationToSeconds(decision.delay) : void 0
    });
    if (!decision.shouldContinue) {
      await checkpoint.checkpoint(stepId, {
        Id: stepId,
        ParentId: parentId,
        Action: import_client_lambda.OperationAction.SUCCEED,
        SubType: OperationSubType.WAIT_FOR_CONDITION,
        Type: import_client_lambda.OperationType.STEP,
        Payload: serializedState,
        Name: name
      });
      log("\u2705", "waitForCondition completed successfully:", {
        stepId,
        name,
        result: deserializedState,
        totalAttempts: currentAttempt
      });
      return deserializedState;
    } else {
      await checkpoint.checkpoint(stepId, {
        Id: stepId,
        ParentId: parentId,
        Action: import_client_lambda.OperationAction.RETRY,
        SubType: OperationSubType.WAIT_FOR_CONDITION,
        Type: import_client_lambda.OperationType.STEP,
        Payload: serializedState,
        // Just the state, not wrapped in an object
        Name: name,
        StepOptions: {
          NextAttemptDelaySeconds: durationToSeconds(decision.delay)
        }
      });
      await waitForContinuation(context, stepId, name, hasRunningOperations, checkpoint, getOperationsEmitter(), onAwaitedChange);
      return CONTINUE_MAIN_LOOP;
    }
  } catch (error) {
    log("\u274C", "waitForCondition check function failed:", {
      stepId,
      name,
      error,
      currentAttempt
    });
    await checkpoint.checkpoint(stepId, {
      Id: stepId,
      ParentId: parentId,
      Action: import_client_lambda.OperationAction.FAIL,
      SubType: OperationSubType.WAIT_FOR_CONDITION,
      Type: import_client_lambda.OperationType.STEP,
      Error: createErrorObjectFromError(error),
      Name: name
    });
    const errorObject = createErrorObjectFromError(error);
    throw DurableOperationError.fromErrorObject(errorObject);
  }
};
var createCallbackPromise = (context, stepId, stepName, serdes, hasRunningOperations, operationsEmitter, terminationMessage, checkAndUpdateReplayMode) => {
  return new DurablePromise(async () => {
    log("\u{1F504}", "Callback promise phase 2 executing:", { stepId, stepName });
    while (true) {
      const stepData = context.getStepData(stepId);
      if (!stepData) {
        log("\u26A0\uFE0F", "Step data not found, waiting for callback creation:", {
          stepId
        });
        if (hasRunningOperations()) {
          await waitBeforeContinue({
            checkHasRunningOperations: true,
            checkStepStatus: true,
            checkTimer: false,
            stepId,
            context,
            hasRunningOperations,
            operationsEmitter
          });
          continue;
        }
        log("\u23F3", "No step data found and no running operations, terminating");
        return terminate(context, TerminationReason.CALLBACK_PENDING, terminationMessage);
      }
      if (stepData.Status === import_client_lambda.OperationStatus.SUCCEEDED) {
        const callbackData = stepData.CallbackDetails;
        if (!callbackData?.CallbackId) {
          throw new CallbackError(`No callback ID found for completed callback: ${stepId}`);
        }
        const result = await safeDeserialize(serdes, callbackData.Result, stepId, stepName, context.terminationManager, context.durableExecutionArn);
        checkAndUpdateReplayMode();
        return result;
      }
      if (stepData.Status === import_client_lambda.OperationStatus.FAILED || stepData.Status === import_client_lambda.OperationStatus.TIMED_OUT) {
        const callbackData = stepData.CallbackDetails;
        const error = callbackData?.Error;
        if (error) {
          const cause = new Error(error.ErrorMessage);
          cause.name = error.ErrorType || "Error";
          cause.stack = error.StackTrace?.join("\n");
          throw new CallbackError(error.ErrorMessage || "Callback failed", cause, error.ErrorData);
        }
        throw new CallbackError("Callback failed");
      }
      if (stepData.Status === import_client_lambda.OperationStatus.STARTED) {
        if (hasRunningOperations()) {
          log("\u23F3", "Callback still pending, waiting for other operations");
          await waitBeforeContinue({
            checkHasRunningOperations: true,
            checkStepStatus: true,
            checkTimer: false,
            stepId,
            context,
            hasRunningOperations,
            operationsEmitter
          });
          continue;
        }
        log("\u23F3", "Callback still pending, terminating");
        return terminate(context, TerminationReason.CALLBACK_PENDING, terminationMessage);
      }
      throw new CallbackError(`Unexpected callback status: ${stepData.Status}`);
    }
  });
};
var createPassThroughSerdes = () => ({
  serialize: async (value) => value,
  deserialize: async (data) => data
});
var createCallback = (context, checkpoint, createStepId, hasRunningOperations, getOperationsEmitter, checkAndUpdateReplayMode, parentId) => {
  return (nameOrConfig, maybeConfig) => {
    let name;
    let config;
    if (typeof nameOrConfig === "string" || nameOrConfig === void 0) {
      name = nameOrConfig;
      config = maybeConfig;
    } else {
      config = nameOrConfig;
    }
    const stepId = createStepId();
    const serdes = config?.serdes || createPassThroughSerdes();
    const stepData = context.getStepData(stepId);
    validateReplayConsistency(stepId, {
      type: import_client_lambda.OperationType.CALLBACK,
      name,
      subType: OperationSubType.CALLBACK
    }, stepData, context);
    const setupPromise = (async () => {
      log("\u{1F4DE}", "Creating callback phase 1:", { stepId, name, config });
      if (stepData?.Status === import_client_lambda.OperationStatus.SUCCEEDED) {
        log("\u23ED\uFE0F", "Callback already completed in phase 1:", { stepId });
        return { wasNewCallback: false };
      }
      if (stepData?.Status === import_client_lambda.OperationStatus.FAILED || stepData?.Status === import_client_lambda.OperationStatus.TIMED_OUT) {
        log("\u274C", "Callback already failed in phase 1:", { stepId });
        return { wasNewCallback: false };
      }
      if (stepData?.Status === import_client_lambda.OperationStatus.STARTED) {
        log("\u23F3", "Callback already started in phase 1:", { stepId });
        return { wasNewCallback: false };
      }
      log("\u{1F195}", "Creating new callback in phase 1:", { stepId, name });
      await checkpoint.checkpoint(stepId, {
        Id: stepId,
        ParentId: parentId,
        Action: "START",
        SubType: OperationSubType.CALLBACK,
        Type: import_client_lambda.OperationType.CALLBACK,
        Name: name,
        CallbackOptions: {
          TimeoutSeconds: config?.timeout ? durationToSeconds(config.timeout) : void 0,
          HeartbeatTimeoutSeconds: config?.heartbeatTimeout ? durationToSeconds(config.heartbeatTimeout) : void 0
        }
      });
      log("\u2705", "Callback checkpoint completed in phase 1:", { stepId });
      return { wasNewCallback: true };
    })().catch((error) => {
      log("\u274C", "Callback phase 1 error:", { stepId, error: error.message });
      throw error;
    });
    return new DurablePromise(async () => {
      const { wasNewCallback } = await setupPromise;
      log("\u{1F504}", "Callback phase 2 executing:", { stepId, name });
      const stepData2 = context.getStepData(stepId);
      if (stepData2?.Status === import_client_lambda.OperationStatus.SUCCEEDED) {
        const callbackData2 = stepData2.CallbackDetails;
        if (!callbackData2?.CallbackId) {
          throw new CallbackError(`No callback ID found for completed callback: ${stepId}`);
        }
        const deserializedResult = await safeDeserialize(serdes, callbackData2.Result, stepId, name, context.terminationManager, context.durableExecutionArn);
        const resolvedPromise = new DurablePromise(async () => deserializedResult);
        checkAndUpdateReplayMode();
        return [resolvedPromise, callbackData2.CallbackId];
      }
      if (stepData2?.Status === import_client_lambda.OperationStatus.FAILED || stepData2?.Status === import_client_lambda.OperationStatus.TIMED_OUT) {
        const callbackData2 = stepData2.CallbackDetails;
        if (!callbackData2?.CallbackId) {
          throw new CallbackError(`No callback ID found for failed callback: ${stepId}`);
        }
        const error = stepData2.CallbackDetails?.Error;
        const callbackError = error ? (() => {
          const cause = new Error(error.ErrorMessage);
          cause.name = error.ErrorType || "Error";
          cause.stack = error.StackTrace?.join("\n");
          return new CallbackError(error.ErrorMessage || "Callback failed", cause, error.ErrorData);
        })() : new CallbackError("Callback failed");
        const rejectedPromise = new DurablePromise(async () => {
          throw callbackError;
        });
        return [rejectedPromise, callbackData2.CallbackId];
      }
      const callbackData = stepData2?.CallbackDetails;
      if (!callbackData?.CallbackId) {
        const errorMessage = wasNewCallback ? `Callback ID not found in stepData after checkpoint: ${stepId}` : `No callback ID found for started callback: ${stepId}`;
        throw new CallbackError(errorMessage);
      }
      const callbackId = callbackData.CallbackId;
      const terminationMessage = wasNewCallback ? `Callback ${name || stepId} created and pending external completion` : `Callback ${name || stepId} is pending external completion`;
      const callbackPromise = createCallbackPromise(context, stepId, name, serdes, hasRunningOperations, getOperationsEmitter(), terminationMessage, checkAndUpdateReplayMode);
      log("\u2705", "Callback created successfully in phase 2:", {
        stepId,
        name,
        callbackId
      });
      return [callbackPromise, callbackId];
    });
  };
};
var createWaitForCallbackHandler = (context, getNextStepId, runInChildContext) => {
  return (nameOrSubmitter, submitterOrConfig, maybeConfig) => {
    let name;
    let submitter;
    let config;
    if (typeof nameOrSubmitter === "string" || nameOrSubmitter === void 0) {
      name = nameOrSubmitter;
      if (typeof submitterOrConfig === "function") {
        submitter = submitterOrConfig;
        config = maybeConfig;
      } else {
        return new DurablePromise(() => Promise.reject(new Error("waitForCallback requires a submitter function when name is provided")));
      }
    } else if (typeof nameOrSubmitter === "function") {
      submitter = nameOrSubmitter;
      config = submitterOrConfig;
    } else {
      return new DurablePromise(() => Promise.reject(new Error("waitForCallback requires a submitter function")));
    }
    const phase1Promise = (async () => {
      log("\u{1F4DE}", "WaitForCallback requested:", {
        name,
        hasSubmitter: !!submitter,
        config
      });
      const childFunction = async (childCtx) => {
        const createCallbackConfig = config ? {
          timeout: config.timeout,
          heartbeatTimeout: config.heartbeatTimeout
        } : void 0;
        const [callbackPromise, callbackId] = await childCtx.createCallback(createCallbackConfig);
        log("\u{1F194}", "Callback created:", {
          callbackId,
          name
        });
        await childCtx.step(async (stepContext) => {
          const callbackContext = {
            logger: stepContext.logger
          };
          log("\u{1F4E4}", "Executing submitter:", {
            callbackId,
            name
          });
          await submitter(callbackId, callbackContext);
          log("\u2705", "Submitter completed:", {
            callbackId,
            name
          });
        }, config?.retryStrategy ? { retryStrategy: config.retryStrategy } : void 0);
        log("\u23F3", "Waiting for callback completion:", {
          callbackId,
          name
        });
        return await callbackPromise;
      };
      const stepId = getNextStepId();
      return {
        result: await runInChildContext(name, childFunction, {
          subType: OperationSubType.WAIT_FOR_CALLBACK
        }),
        stepId
      };
    })();
    phase1Promise.catch(() => {
    });
    return new DurablePromise(async () => {
      const { result, stepId } = await phase1Promise;
      return await safeDeserialize(config?.serdes ?? createPassThroughSerdes(), result, stepId, name, context.terminationManager, context.durableExecutionArn);
    });
  };
};
var createParallelSummaryGenerator = () => (result) => {
  return JSON.stringify({
    type: "ParallelResult",
    totalCount: result.totalCount,
    successCount: result.successCount,
    failureCount: result.failureCount,
    startedCount: result.startedCount,
    completionReason: result.completionReason,
    status: result.status
  });
};
var createMapSummaryGenerator = () => (result) => {
  return JSON.stringify({
    type: "MapResult",
    totalCount: result.totalCount,
    successCount: result.successCount,
    failureCount: result.failureCount,
    completionReason: result.completionReason,
    status: result.status
  });
};
var createMapHandler = (context, executeConcurrently) => {
  return (nameOrItems, itemsOrMapFunc, mapFuncOrConfig, maybeConfig) => {
    const phase1Promise = (async () => {
      let name;
      let items;
      let mapFunc;
      let config;
      if (typeof nameOrItems === "string" || nameOrItems === void 0) {
        name = nameOrItems;
        items = itemsOrMapFunc;
        mapFunc = mapFuncOrConfig;
        config = maybeConfig;
      } else {
        items = nameOrItems;
        mapFunc = itemsOrMapFunc;
        config = mapFuncOrConfig;
      }
      log("\u{1F5FA}\uFE0F", "Starting map operation:", {
        name,
        itemCount: items.length,
        maxConcurrency: config?.maxConcurrency
      });
      if (!Array.isArray(items)) {
        throw new Error("Map operation requires an array of items");
      }
      if (typeof mapFunc !== "function") {
        throw new Error("Map operation requires a function to process items");
      }
      const executionItems = items.map((item, index) => ({
        id: `map-item-${index}`,
        data: item,
        index,
        name: config?.itemNamer ? config.itemNamer(item, index) : void 0
      }));
      const executor = async (executionItem, childContext) => mapFunc(childContext, executionItem.data, executionItem.index, items);
      const result = await executeConcurrently(name, executionItems, executor, {
        maxConcurrency: config?.maxConcurrency,
        topLevelSubType: OperationSubType.MAP,
        iterationSubType: OperationSubType.MAP_ITERATION,
        summaryGenerator: createMapSummaryGenerator(),
        completionConfig: config?.completionConfig,
        serdes: config?.serdes,
        itemSerdes: config?.itemSerdes
      });
      log("\u{1F5FA}\uFE0F", "Map operation completed successfully:", {
        resultCount: result.totalCount
      });
      return result;
    })();
    phase1Promise.catch(() => {
    });
    return new DurablePromise(async () => {
      return await phase1Promise;
    });
  };
};
var createParallelHandler = (context, executeConcurrently) => {
  return (nameOrBranches, branchesOrConfig, maybeConfig) => {
    const phase1Promise = (async () => {
      let name;
      let branches;
      let config;
      if (typeof nameOrBranches === "string" || nameOrBranches === void 0) {
        name = nameOrBranches;
        branches = branchesOrConfig;
        config = maybeConfig;
      } else {
        branches = nameOrBranches;
        config = branchesOrConfig;
      }
      if (!Array.isArray(branches)) {
        throw new Error("Parallel operation requires an array of branch functions");
      }
      log("\u{1F500}", "Starting parallel operation:", {
        name,
        branchCount: branches.length,
        maxConcurrency: config?.maxConcurrency
      });
      if (branches.some((branch) => typeof branch !== "function" && (typeof branch !== "object" || typeof branch.func !== "function"))) {
        throw new Error("All branches must be functions or NamedParallelBranch objects");
      }
      const executionItems = branches.map((branch, index) => {
        const isNamedBranch = typeof branch === "object" && "func" in branch;
        const func = isNamedBranch ? branch.func : branch;
        const branchName = isNamedBranch ? branch.name : void 0;
        return {
          id: `parallel-branch-${index}`,
          data: func,
          index,
          name: branchName
        };
      });
      const executor = async (executionItem, childContext) => {
        log("\u{1F500}", "Processing parallel branch:", {
          index: executionItem.index
        });
        const result2 = await executionItem.data(childContext);
        log("\u2705", "Parallel branch completed:", {
          index: executionItem.index,
          result: result2
        });
        return result2;
      };
      const result = await executeConcurrently(name, executionItems, executor, {
        maxConcurrency: config?.maxConcurrency,
        topLevelSubType: OperationSubType.PARALLEL,
        iterationSubType: OperationSubType.PARALLEL_BRANCH,
        summaryGenerator: createParallelSummaryGenerator(),
        completionConfig: config?.completionConfig,
        serdes: config?.serdes,
        itemSerdes: config?.itemSerdes
      });
      log("\u{1F500}", "Parallel operation completed successfully:", {
        resultCount: result.totalCount
      });
      return result;
    })();
    phase1Promise.catch(() => {
    });
    return new DurablePromise(async () => {
      return await phase1Promise;
    });
  };
};
function decorateErrors(value) {
  return value.map((item) => {
    if (item && item.status === "rejected" && item.reason instanceof Error) {
      return {
        ...item,
        reason: {
          message: item.reason.message,
          name: item.reason.name,
          stack: item.reason.stack
        }
      };
    }
    return item;
  });
}
function restoreErrors(value) {
  return value.map((item) => {
    if (item && item.status === "rejected" && item.reason && typeof item.reason === "object" && item.reason.message) {
      const error = new Error(item.reason.message);
      error.name = item.reason.name || "Error";
      if (item.reason.stack)
        error.stack = item.reason.stack;
      return {
        ...item,
        reason: error
      };
    }
    return item;
  });
}
function createErrorAwareSerdes() {
  return {
    serialize: async (value, _context) => value !== void 0 ? JSON.stringify(decorateErrors(value)) : void 0,
    deserialize: async (data, _context) => data !== void 0 ? restoreErrors(JSON.parse(data)) : void 0
  };
}
var stepConfig = {
  retryStrategy: () => ({
    shouldRetry: false
  })
};
var createPromiseHandler = (step) => {
  const parseParams = (nameOrPromises, maybePromises) => {
    if (typeof nameOrPromises === "string" || nameOrPromises === void 0) {
      return { name: nameOrPromises, promises: maybePromises };
    }
    return { name: void 0, promises: nameOrPromises };
  };
  const all = (nameOrPromises, maybePromises) => {
    return new DurablePromise(async () => {
      const { name, promises } = parseParams(nameOrPromises, maybePromises);
      return await step(name, () => Promise.all(promises), stepConfig);
    });
  };
  const allSettled = (nameOrPromises, maybePromises) => {
    return new DurablePromise(async () => {
      const { name, promises } = parseParams(nameOrPromises, maybePromises);
      return await step(name, () => Promise.allSettled(promises), {
        ...stepConfig,
        serdes: createErrorAwareSerdes()
      });
    });
  };
  const any = (nameOrPromises, maybePromises) => {
    return new DurablePromise(async () => {
      const { name, promises } = parseParams(nameOrPromises, maybePromises);
      return await step(name, () => Promise.any(promises), stepConfig);
    });
  };
  const race = (nameOrPromises, maybePromises) => {
    return new DurablePromise(async () => {
      const { name, promises } = parseParams(nameOrPromises, maybePromises);
      return await step(name, () => Promise.race(promises), stepConfig);
    });
  };
  return {
    all,
    allSettled,
    any,
    race
  };
};
var BatchResultImpl = class {
  all;
  completionReason;
  constructor(all, completionReason) {
    this.all = all;
    this.completionReason = completionReason;
  }
  succeeded() {
    return this.all.filter((item) => item.status === BatchItemStatus.SUCCEEDED && item.result !== void 0);
  }
  failed() {
    return this.all.filter((item) => item.status === BatchItemStatus.FAILED && item.error !== void 0);
  }
  started() {
    return this.all.filter((item) => item.status === BatchItemStatus.STARTED);
  }
  get status() {
    return this.hasFailure ? BatchItemStatus.FAILED : BatchItemStatus.SUCCEEDED;
  }
  get hasFailure() {
    return this.all.some((item) => item.status === BatchItemStatus.FAILED);
  }
  throwIfError() {
    const firstError = this.all.find((item) => item.status === BatchItemStatus.FAILED)?.error;
    if (firstError) {
      throw firstError;
    }
  }
  getResults() {
    return this.succeeded().map((item) => item.result);
  }
  getErrors() {
    return this.failed().map((item) => item.error);
  }
  get successCount() {
    return this.all.filter((item) => item.status === BatchItemStatus.SUCCEEDED).length;
  }
  get failureCount() {
    return this.all.filter((item) => item.status === BatchItemStatus.FAILED).length;
  }
  get startedCount() {
    return this.all.filter((item) => item.status === BatchItemStatus.STARTED).length;
  }
  get totalCount() {
    return this.all.length;
  }
};
function restoreBatchResult(data) {
  if (data && typeof data === "object" && "all" in data && Array.isArray(data.all)) {
    const serializedData = data;
    const restoredItems = serializedData.all.map((item) => ({
      ...item,
      result: item.result,
      error: item.error ? DurableOperationError.fromErrorObject(item.error) : void 0
    }));
    return new BatchResultImpl(restoredItems, serializedData.completionReason);
  }
  return new BatchResultImpl([], "ALL_COMPLETED");
}
var ConcurrencyController = class {
  operationName;
  skipNextOperation;
  constructor(operationName, skipNextOperation) {
    this.operationName = operationName;
    this.skipNextOperation = skipNextOperation;
  }
  isChildEntityCompleted(executionContext, parentEntityId, completedCount) {
    const childEntityId = `${parentEntityId}-${completedCount + 1}`;
    const childStepData = executionContext.getStepData(childEntityId);
    return !!(childStepData && (childStepData.Status === import_client_lambda.OperationStatus.SUCCEEDED || childStepData.Status === import_client_lambda.OperationStatus.FAILED));
  }
  async executeItems(items, executor, parentContext, config, durableExecutionMode = DurableExecutionMode.ExecutionMode, entityId, executionContext) {
    if (durableExecutionMode === DurableExecutionMode.ReplaySucceededContext) {
      log("\u{1F504}", `Replay mode: Reconstructing ${this.operationName} result:`, {
        itemCount: items.length
      });
      let targetTotalCount;
      if (entityId && executionContext) {
        const stepData = executionContext.getStepData(entityId);
        const summaryPayload = stepData?.ContextDetails?.Result;
        if (summaryPayload) {
          try {
            const serdes = config.serdes || defaultSerdes;
            const parsedSummary = await serdes.deserialize(summaryPayload, {
              entityId,
              durableExecutionArn: executionContext.durableExecutionArn
            });
            if (parsedSummary && typeof parsedSummary === "object" && "totalCount" in parsedSummary) {
              targetTotalCount = parsedSummary.totalCount;
              log("\u{1F4CA}", "Found initial execution count:", {
                targetTotalCount
              });
            }
          } catch (error) {
            log("\u26A0\uFE0F", "Could not parse initial result summary:", error);
          }
        }
      }
      if (targetTotalCount !== void 0 && entityId && executionContext) {
        return await this.replayItems(items, executor, parentContext, config, targetTotalCount, executionContext, entityId);
      } else {
        log("\u26A0\uFE0F", "No valid target count or context found, falling back to concurrent execution");
      }
    }
    return await this.executeItemsConcurrently(items, executor, parentContext, config);
  }
  async replayItems(items, executor, parentContext, config, targetTotalCount, executionContext, parentEntityId) {
    const resultItems = [];
    log("\u{1F504}", `Replaying ${items.length} items sequentially`, {
      targetTotalCount
    });
    let completedCount = 0;
    let stepCounter = 0;
    for (const item of items) {
      if (completedCount >= targetTotalCount) {
        log("\u2705", "Reached target count, stopping replay", {
          completedCount,
          targetTotalCount
        });
        break;
      }
      const childEntityId = `${parentEntityId}-${stepCounter + 1}`;
      if (!this.isChildEntityCompleted(executionContext, parentEntityId, stepCounter)) {
        log("\u23ED\uFE0F", `Skipping incomplete item:`, {
          index: item.index,
          itemId: item.id,
          childEntityId
        });
        this.skipNextOperation();
        stepCounter++;
        continue;
      }
      try {
        const result = await parentContext.runInChildContext(item.name || item.id, (childContext) => executor(item, childContext), { subType: config.iterationSubType, serdes: config.itemSerdes });
        resultItems.push({
          result,
          index: item.index,
          status: BatchItemStatus.SUCCEEDED
        });
        completedCount++;
        stepCounter++;
        log("\u2705", `Replayed ${this.operationName} item:`, {
          index: item.index,
          itemId: item.id,
          completedCount
        });
      } catch (error) {
        const err = error instanceof ChildContextError ? error : new ChildContextError(error instanceof Error ? error.message : String(error), error instanceof Error ? error : void 0);
        resultItems.push({
          error: err,
          index: item.index,
          status: BatchItemStatus.FAILED
        });
        completedCount++;
        stepCounter++;
        log("\u274C", `Replay failed for ${this.operationName} item:`, {
          index: item.index,
          itemId: item.id,
          error: err.message,
          completedCount
        });
      }
    }
    log("\u{1F389}", `${this.operationName} replay completed:`, {
      completedCount,
      totalCount: resultItems.length
    });
    const successCount = resultItems.filter((item) => item.status === BatchItemStatus.SUCCEEDED).length;
    const getCompletionReason = () => {
      if (completedCount === items.length)
        return "ALL_COMPLETED";
      if (config.completionConfig?.minSuccessful !== void 0 && successCount >= config.completionConfig.minSuccessful)
        return "MIN_SUCCESSFUL_REACHED";
      return "FAILURE_TOLERANCE_EXCEEDED";
    };
    return new BatchResultImpl(resultItems, getCompletionReason());
  }
  async executeItemsConcurrently(items, executor, parentContext, config) {
    const maxConcurrency = config.maxConcurrency || Infinity;
    const resultItems = new Array(items.length);
    const startedItems = /* @__PURE__ */ new Set();
    let activeCount = 0;
    let currentIndex = 0;
    let completedCount = 0;
    let successCount = 0;
    let failureCount = 0;
    log("\u{1F680}", `Starting ${this.operationName} with concurrency control:`, {
      itemCount: items.length,
      maxConcurrency
    });
    return new Promise((resolve) => {
      const shouldContinue = () => {
        const completion = config.completionConfig;
        if (!completion)
          return failureCount === 0;
        const hasAnyCompletionCriteria = Object.values(completion).some((value) => value !== void 0);
        if (!hasAnyCompletionCriteria) {
          return failureCount === 0;
        }
        if (completion.toleratedFailureCount !== void 0 && failureCount > completion.toleratedFailureCount)
          return false;
        if (completion.toleratedFailurePercentage !== void 0) {
          const failurePercentage = failureCount / items.length * 100;
          if (failurePercentage > completion.toleratedFailurePercentage)
            return false;
        }
        return true;
      };
      const isComplete = () => {
        if (completedCount === items.length) {
          return true;
        }
        const completion = config.completionConfig;
        if (completion?.minSuccessful !== void 0 && successCount >= completion.minSuccessful) {
          return true;
        }
        return false;
      };
      const getCompletionReason = () => {
        if (completedCount === items.length)
          return "ALL_COMPLETED";
        if (config.completionConfig?.minSuccessful !== void 0 && successCount >= config.completionConfig.minSuccessful)
          return "MIN_SUCCESSFUL_REACHED";
        return "FAILURE_TOLERANCE_EXCEEDED";
      };
      const tryStartNext = () => {
        while (activeCount < maxConcurrency && currentIndex < items.length && shouldContinue()) {
          const index = currentIndex++;
          const item = items[index];
          startedItems.add(index);
          activeCount++;
          resultItems[index] = { index, status: BatchItemStatus.STARTED };
          log("\u25B6\uFE0F", `Starting ${this.operationName} item:`, {
            index,
            itemId: item.id,
            itemName: item.name
          });
          parentContext.runInChildContext(item.name || item.id, (childContext) => executor(item, childContext), { subType: config.iterationSubType, serdes: config.itemSerdes }).then((result) => {
            resultItems[index] = {
              result,
              index,
              status: BatchItemStatus.SUCCEEDED
            };
            successCount++;
            log("\u2705", `${this.operationName} item completed:`, {
              index,
              itemId: item.id,
              itemName: item.name
            });
            onComplete();
          }, (error) => {
            const err = error instanceof ChildContextError ? error : new ChildContextError(error instanceof Error ? error.message : String(error), error instanceof Error ? error : void 0);
            resultItems[index] = {
              error: err,
              index,
              status: BatchItemStatus.FAILED
            };
            failureCount++;
            log("\u274C", `${this.operationName} item failed:`, {
              index,
              itemId: item.id,
              itemName: item.name,
              error: err.message
            });
            onComplete();
          });
        }
      };
      const onComplete = () => {
        activeCount--;
        completedCount++;
        if (isComplete() || !shouldContinue()) {
          const finalBatchItems = [];
          for (let i = 0; i < resultItems.length; i++) {
            if (resultItems[i] !== void 0) {
              finalBatchItems.push({ ...resultItems[i] });
            }
          }
          log("\u{1F389}", `${this.operationName} completed:`, {
            successCount,
            failureCount,
            startedCount: finalBatchItems.filter((item) => item.status === BatchItemStatus.STARTED).length,
            totalCount: finalBatchItems.length
          });
          const result = new BatchResultImpl(finalBatchItems, getCompletionReason());
          resolve(result);
        } else {
          tryStartNext();
        }
      };
      tryStartNext();
    });
  }
};
var createConcurrentExecutionHandler = (context, runInChildContext, skipNextOperation) => {
  return (nameOrItems, itemsOrExecutor, executorOrConfig, maybeConfig) => {
    const phase1Promise = (async () => {
      let name;
      let items;
      let executor;
      let config;
      if (typeof nameOrItems === "string" || nameOrItems === void 0) {
        name = nameOrItems;
        items = itemsOrExecutor;
        executor = executorOrConfig;
        config = maybeConfig;
      } else {
        items = nameOrItems;
        executor = itemsOrExecutor;
        config = executorOrConfig;
      }
      log("\u{1F504}", "Starting concurrent execution:", {
        name,
        itemCount: items.length,
        maxConcurrency: config?.maxConcurrency
      });
      if (!Array.isArray(items)) {
        throw new Error("Concurrent execution requires an array of items");
      }
      if (typeof executor !== "function") {
        throw new Error("Concurrent execution requires an executor function");
      }
      if (config?.maxConcurrency !== void 0 && config.maxConcurrency !== null && config.maxConcurrency <= 0) {
        throw new Error(`Invalid maxConcurrency: ${config.maxConcurrency}. Must be a positive number or undefined for unlimited concurrency.`);
      }
      const executeOperation = async (executionContext) => {
        const concurrencyController = new ConcurrencyController("concurrent-execution", skipNextOperation);
        const durableExecutionMode = executionContext.durableExecutionMode;
        const entityId = executionContext._stepPrefix;
        log("\u{1F504}", "Concurrent execution mode:", {
          mode: durableExecutionMode,
          itemCount: items.length,
          entityId
        });
        return await concurrencyController.executeItems(items, executor, executionContext, config || {}, durableExecutionMode, entityId, context);
      };
      const result = await runInChildContext(name, executeOperation, {
        subType: config?.topLevelSubType,
        summaryGenerator: config?.summaryGenerator,
        serdes: config?.serdes
      });
      if (result && typeof result === "object" && "all" in result && Array.isArray(result.all)) {
        return restoreBatchResult(result);
      }
      return result;
    })();
    phase1Promise.catch(() => {
    });
    return new DurablePromise(async () => {
      return await phase1Promise;
    });
  };
};
var ModeManagement = class {
  captureExecutionState;
  checkAndUpdateReplayMode;
  checkForNonResolvingPromise;
  getDurableExecutionMode;
  setDurableExecutionMode;
  constructor(captureExecutionState, checkAndUpdateReplayMode, checkForNonResolvingPromise, getDurableExecutionMode, setDurableExecutionMode) {
    this.captureExecutionState = captureExecutionState;
    this.checkAndUpdateReplayMode = checkAndUpdateReplayMode;
    this.checkForNonResolvingPromise = checkForNonResolvingPromise;
    this.getDurableExecutionMode = getDurableExecutionMode;
    this.setDurableExecutionMode = setDurableExecutionMode;
  }
  withModeManagement(operation) {
    const shouldSwitchToExecutionMode = this.captureExecutionState();
    this.checkAndUpdateReplayMode();
    const nonResolvingPromise = this.checkForNonResolvingPromise();
    if (nonResolvingPromise)
      return nonResolvingPromise;
    try {
      return operation();
    } finally {
      if (shouldSwitchToExecutionMode) {
        this.setDurableExecutionMode(DurableExecutionMode.ExecutionMode);
      }
    }
  }
  withDurableModeManagement(operation) {
    const shouldSwitchToExecutionMode = this.captureExecutionState();
    this.checkAndUpdateReplayMode();
    const nonResolvingPromise = this.checkForNonResolvingPromise();
    if (nonResolvingPromise) {
      return new DurablePromise(async () => {
        await nonResolvingPromise;
        throw new Error("Unreachable code");
      });
    }
    try {
      return operation();
    } finally {
      if (shouldSwitchToExecutionMode) {
        this.setDurableExecutionMode(DurableExecutionMode.ExecutionMode);
      }
    }
  }
};
var DurableContextImpl = class {
  executionContext;
  lambdaContext;
  _stepPrefix;
  _stepCounter = 0;
  durableLogger;
  modeAwareLoggingEnabled = true;
  runningOperations = /* @__PURE__ */ new Set();
  operationsEmitter = new import_events.EventEmitter();
  checkpoint;
  durableExecutionMode;
  _parentId;
  modeManagement;
  durableExecution;
  logger;
  constructor(executionContext, lambdaContext, durableExecutionMode, inheritedLogger, stepPrefix, durableExecution, parentId) {
    this.executionContext = executionContext;
    this.lambdaContext = lambdaContext;
    this._stepPrefix = stepPrefix;
    this._parentId = parentId;
    this.durableExecution = durableExecution;
    this.durableLogger = inheritedLogger;
    this.durableLogger.configureDurableLoggingContext?.(this.getDurableLoggingContext());
    this.logger = this.createModeAwareLogger(inheritedLogger);
    this.durableExecutionMode = durableExecutionMode;
    this.checkpoint = durableExecution.checkpointManager;
    this.modeManagement = new ModeManagement(this.captureExecutionState.bind(this), this.checkAndUpdateReplayMode.bind(this), this.checkForNonResolvingPromise.bind(this), () => this.durableExecutionMode, (mode) => {
      this.durableExecutionMode = mode;
    });
  }
  getDurableLoggingContext() {
    return {
      getDurableLogData: () => {
        const activeContext = getActiveContext();
        const result = {
          executionArn: this.executionContext.durableExecutionArn,
          requestId: this.executionContext.requestId,
          tenantId: this.executionContext.tenantId,
          operationId: !activeContext || activeContext?.contextId === "root" ? void 0 : hashId(activeContext.contextId)
        };
        if (activeContext?.attempt !== void 0) {
          result.attempt = activeContext.attempt;
        }
        return result;
      }
    };
  }
  shouldLog() {
    const activeContext = getActiveContext();
    if (!this.modeAwareLoggingEnabled || !activeContext) {
      return true;
    }
    if (activeContext.contextId === "root") {
      return this.durableExecutionMode === DurableExecutionMode.ExecutionMode;
    }
    return activeContext.durableExecutionMode === DurableExecutionMode.ExecutionMode;
  }
  createModeAwareLogger(logger) {
    const durableContextLogger = {
      warn: (...args) => {
        if (this.shouldLog()) {
          return logger.warn(...args);
        }
      },
      debug: (...args) => {
        if (this.shouldLog()) {
          return logger.debug(...args);
        }
      },
      info: (...args) => {
        if (this.shouldLog()) {
          return logger.info(...args);
        }
      },
      error: (...args) => {
        if (this.shouldLog()) {
          return logger.error(...args);
        }
      }
    };
    if ("log" in logger) {
      durableContextLogger.log = (level, ...args) => {
        if (this.shouldLog()) {
          return logger.log?.(level, ...args);
        }
      };
    }
    return durableContextLogger;
  }
  createStepId() {
    this._stepCounter++;
    return this._stepPrefix ? `${this._stepPrefix}-${this._stepCounter}` : `${this._stepCounter}`;
  }
  getNextStepId() {
    const nextCounter = this._stepCounter + 1;
    return this._stepPrefix ? `${this._stepPrefix}-${nextCounter}` : `${nextCounter}`;
  }
  /**
   * Skips the next operation by incrementing the step counter.
   * Used internally by concurrent execution handler during replay to skip incomplete items.
   * @internal
   */
  skipNextOperation() {
    this._stepCounter++;
  }
  checkAndUpdateReplayMode() {
    if (this.durableExecutionMode === DurableExecutionMode.ReplayMode) {
      const nextStepId = this.getNextStepId();
      const nextStepData = this.executionContext.getStepData(nextStepId);
      if (!nextStepData) {
        this.durableExecutionMode = DurableExecutionMode.ExecutionMode;
      }
    }
  }
  captureExecutionState() {
    const wasInReplayMode = this.durableExecutionMode === DurableExecutionMode.ReplayMode;
    const nextStepId = this.getNextStepId();
    const stepData = this.executionContext.getStepData(nextStepId);
    const wasNotFinished = !!(stepData && stepData.Status !== import_client_lambda.OperationStatus.SUCCEEDED && stepData.Status !== import_client_lambda.OperationStatus.FAILED);
    return wasInReplayMode && wasNotFinished;
  }
  checkForNonResolvingPromise() {
    if (this.durableExecutionMode === DurableExecutionMode.ReplaySucceededContext) {
      const nextStepId = this.getNextStepId();
      const nextStepData = this.executionContext.getStepData(nextStepId);
      if (nextStepData && nextStepData.Status !== import_client_lambda.OperationStatus.SUCCEEDED && nextStepData.Status !== import_client_lambda.OperationStatus.FAILED) {
        return new Promise(() => {
        });
      }
    }
    return null;
  }
  addRunningOperation(stepId) {
    this.runningOperations.add(stepId);
  }
  removeRunningOperation(stepId) {
    this.runningOperations.delete(stepId);
    if (this.runningOperations.size === 0) {
      this.operationsEmitter.emit(OPERATIONS_COMPLETE_EVENT);
    }
  }
  hasRunningOperations() {
    return this.runningOperations.size > 0;
  }
  getOperationsEmitter() {
    return this.operationsEmitter;
  }
  withModeManagement(operation) {
    return this.modeManagement.withModeManagement(operation);
  }
  withDurableModeManagement(operation) {
    return this.modeManagement.withDurableModeManagement(operation);
  }
  step(nameOrFn, fnOrOptions, maybeOptions) {
    validateContextUsage(this._stepPrefix, "step", this.executionContext.terminationManager);
    return this.withDurableModeManagement(() => {
      const stepHandler = createStepHandler(this.executionContext, this.checkpoint, this.lambdaContext, this.createStepId.bind(this), this.durableLogger, this.addRunningOperation.bind(this), this.removeRunningOperation.bind(this), this.hasRunningOperations.bind(this), this.getOperationsEmitter.bind(this), this._parentId);
      return stepHandler(nameOrFn, fnOrOptions, maybeOptions);
    });
  }
  invoke(nameOrFuncId, funcIdOrInput, inputOrConfig, maybeConfig) {
    validateContextUsage(this._stepPrefix, "invoke", this.executionContext.terminationManager);
    return this.withDurableModeManagement(() => {
      const invokeHandler = createInvokeHandler(this.executionContext, this.checkpoint, this.createStepId.bind(this), this.hasRunningOperations.bind(this), this.getOperationsEmitter.bind(this), this._parentId, this.checkAndUpdateReplayMode.bind(this));
      return invokeHandler(...[
        nameOrFuncId,
        funcIdOrInput,
        inputOrConfig,
        maybeConfig
      ]);
    });
  }
  runInChildContext(nameOrFn, fnOrOptions, maybeOptions) {
    validateContextUsage(this._stepPrefix, "runInChildContext", this.executionContext.terminationManager);
    return this.withDurableModeManagement(() => {
      const blockHandler = createRunInChildContextHandler(
        this.executionContext,
        this.checkpoint,
        this.lambdaContext,
        this.createStepId.bind(this),
        () => this.durableLogger,
        // Adapter function to maintain compatibility
        (executionContext, parentContext, durableExecutionMode, inheritedLogger, stepPrefix, _checkpointToken, parentId) => createDurableContext(executionContext, parentContext, durableExecutionMode, inheritedLogger, stepPrefix, this.durableExecution, parentId),
        this._parentId
      );
      return blockHandler(nameOrFn, fnOrOptions, maybeOptions);
    });
  }
  wait(nameOrDuration, maybeDuration) {
    validateContextUsage(this._stepPrefix, "wait", this.executionContext.terminationManager);
    return this.withDurableModeManagement(() => {
      const waitHandler = createWaitHandler(this.executionContext, this.checkpoint, this.createStepId.bind(this), this.hasRunningOperations.bind(this), this.getOperationsEmitter.bind(this), this._parentId, this.checkAndUpdateReplayMode.bind(this));
      return typeof nameOrDuration === "string" ? waitHandler(nameOrDuration, maybeDuration) : waitHandler(nameOrDuration);
    });
  }
  /**
   * Configure logger behavior for this context
   *
   * This method allows partial configuration - only the properties provided will be updated.
   * For example, calling configureLogger(\{ modeAware: false \}) will only change the modeAware
   * setting without affecting any previously configured custom logger.
   *
   * @param config - Logger configuration options including customLogger and modeAware settings (default: modeAware=true)
   * @example
   * // Set custom logger and enable mode-aware logging
   * context.configureLogger(\{ customLogger: myLogger, modeAware: true \});
   *
   * // Later, disable mode-aware logging without changing the custom logger
   * context.configureLogger(\{ modeAware: false \});
   */
  configureLogger(config) {
    if (config.customLogger !== void 0) {
      this.durableLogger = config.customLogger;
      this.durableLogger.configureDurableLoggingContext?.(this.getDurableLoggingContext());
      this.logger = this.createModeAwareLogger(this.durableLogger);
    }
    if (config.modeAware !== void 0) {
      this.modeAwareLoggingEnabled = config.modeAware;
    }
  }
  createCallback(nameOrConfig, maybeConfig) {
    validateContextUsage(this._stepPrefix, "createCallback", this.executionContext.terminationManager);
    return this.withDurableModeManagement(() => {
      const callbackFactory = createCallback(this.executionContext, this.checkpoint, this.createStepId.bind(this), this.hasRunningOperations.bind(this), this.getOperationsEmitter.bind(this), this.checkAndUpdateReplayMode.bind(this), this._parentId);
      return callbackFactory(nameOrConfig, maybeConfig);
    });
  }
  waitForCallback(nameOrSubmitter, submitterOrConfig, maybeConfig) {
    validateContextUsage(this._stepPrefix, "waitForCallback", this.executionContext.terminationManager);
    return this.withDurableModeManagement(() => {
      const waitForCallbackHandler = createWaitForCallbackHandler(this.executionContext, this.getNextStepId.bind(this), this.runInChildContext.bind(this));
      return waitForCallbackHandler(nameOrSubmitter, submitterOrConfig, maybeConfig);
    });
  }
  waitForCondition(nameOrCheckFunc, checkFuncOrConfig, maybeConfig) {
    validateContextUsage(this._stepPrefix, "waitForCondition", this.executionContext.terminationManager);
    return this.withDurableModeManagement(() => {
      const waitForConditionHandler = createWaitForConditionHandler(this.executionContext, this.checkpoint, this.createStepId.bind(this), this.durableLogger, this.addRunningOperation.bind(this), this.removeRunningOperation.bind(this), this.hasRunningOperations.bind(this), this.getOperationsEmitter.bind(this), this._parentId);
      return typeof nameOrCheckFunc === "string" || nameOrCheckFunc === void 0 ? waitForConditionHandler(nameOrCheckFunc, checkFuncOrConfig, maybeConfig) : waitForConditionHandler(nameOrCheckFunc, checkFuncOrConfig);
    });
  }
  map(nameOrItems, itemsOrMapFunc, mapFuncOrConfig, maybeConfig) {
    validateContextUsage(this._stepPrefix, "map", this.executionContext.terminationManager);
    return this.withDurableModeManagement(() => {
      const mapHandler = createMapHandler(this.executionContext, this._executeConcurrently.bind(this));
      return mapHandler(nameOrItems, itemsOrMapFunc, mapFuncOrConfig, maybeConfig);
    });
  }
  parallel(nameOrBranches, branchesOrConfig, maybeConfig) {
    validateContextUsage(this._stepPrefix, "parallel", this.executionContext.terminationManager);
    return this.withDurableModeManagement(() => {
      const parallelHandler = createParallelHandler(this.executionContext, this._executeConcurrently.bind(this));
      return parallelHandler(nameOrBranches, branchesOrConfig, maybeConfig);
    });
  }
  _executeConcurrently(nameOrItems, itemsOrExecutor, executorOrConfig, maybeConfig) {
    validateContextUsage(this._stepPrefix, "_executeConcurrently", this.executionContext.terminationManager);
    return this.withDurableModeManagement(() => {
      const concurrentExecutionHandler = createConcurrentExecutionHandler(this.executionContext, this.runInChildContext.bind(this), this.skipNextOperation.bind(this));
      const promise = concurrentExecutionHandler(nameOrItems, itemsOrExecutor, executorOrConfig, maybeConfig);
      promise?.catch(() => {
      });
      return promise;
    });
  }
  get promise() {
    return createPromiseHandler(this.step.bind(this));
  }
};
var createDurableContext = (executionContext, parentContext, durableExecutionMode, inheritedLogger, stepPrefix, durableExecution, parentId) => {
  return new DurableContextImpl(executionContext, parentContext, durableExecutionMode, inheritedLogger, stepPrefix, durableExecution, parentId);
};
var TerminationManager = class extends import_events.EventEmitter {
  isTerminated = false;
  terminationDetails;
  resolveTermination;
  terminationPromise;
  setCheckpointTerminating;
  constructor(setCheckpointTerminating) {
    super();
    this.setCheckpointTerminating = setCheckpointTerminating;
    this.terminationPromise = new Promise((resolve) => {
      this.resolveTermination = resolve;
    });
  }
  setCheckpointTerminatingCallback(callback) {
    this.setCheckpointTerminating = callback;
  }
  terminate(options = {}) {
    if (this.isTerminated)
      return;
    this.setCheckpointTerminating?.();
    this.isTerminated = true;
    this.terminationDetails = {
      reason: options.reason ?? TerminationReason.OPERATION_TERMINATED,
      message: options.message ?? "Operation terminated",
      error: options.error,
      cleanup: options.cleanup
    };
    if (this.resolveTermination) {
      this.handleTermination(this.terminationDetails).then(this.resolveTermination);
    }
  }
  getTerminationPromise() {
    return this.terminationPromise;
  }
  async handleTermination(details) {
    if (details.cleanup) {
      try {
        await details.cleanup();
      } catch {
      }
    }
    return {
      reason: details.reason,
      message: details.message,
      error: details.error
    };
  }
};
function jsonErrorReplacer(_key, value) {
  if (value instanceof Error) {
    return Object.assign({
      errorType: value?.constructor?.name ?? "UnknownError",
      errorMessage: value.message,
      stackTrace: typeof value.stack === "string" ? value.stack.split("\n") : value.stack
    }, value);
  }
  return value;
}
function formatDurableLogData(level, logData, ...messageParams) {
  const result = {
    requestId: logData.requestId,
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    level: level.toUpperCase(),
    executionArn: logData.executionArn
  };
  const tenantId = logData.tenantId;
  if (tenantId != void 0 && tenantId != null) {
    result.tenantId = tenantId;
  }
  if (logData.operationId !== void 0) {
    result.operationId = logData.operationId;
  }
  if (logData.attempt !== void 0) {
    result.attempt = logData.attempt;
  }
  if (messageParams.length === 1) {
    result.message = messageParams[0];
    try {
      return JSON.stringify(result, jsonErrorReplacer);
    } catch (_) {
      result.message = import_node_util.default.format(result.message);
      return JSON.stringify(result);
    }
  }
  result.message = import_node_util.default.format(...messageParams);
  for (const param of messageParams) {
    if (param instanceof Error) {
      result.errorType = param?.constructor?.name ?? "UnknownError";
      result.errorMessage = param.message;
      result.stackTrace = typeof param.stack === "string" ? param.stack.split("\n") : [];
      break;
    }
  }
  return JSON.stringify(result);
}
var DefaultLogger = class {
  consoleLogger;
  durableLoggingContext = void 0;
  executionContext;
  noOpLog = () => {
  };
  constructor(executionContext) {
    this.executionContext = executionContext;
    this.consoleLogger = new import_node_console.Console({
      stdout: process.stdout,
      stderr: process.stderr
    });
    this.info = this.noOpLog;
    this.error = this.noOpLog;
    this.warn = this.noOpLog;
    this.debug = this.noOpLog;
    this.configureLogLevel();
  }
  configureLogLevel() {
    const levels = {
      DEBUG: { name: "DEBUG", priority: 2 },
      INFO: { name: "INFO", priority: 3 },
      WARN: { name: "WARN", priority: 4 },
      ERROR: { name: "ERROR", priority: 5 }
      // Not implemented yet. Can be implemented later
      // TRACE: { name: "TRACE", priority: 1 },
      // FATAL: { name: "FATAL", priority: 6 },
    };
    const logLevelEnvVariable = process.env["AWS_LAMBDA_LOG_LEVEL"]?.toUpperCase();
    const lambdaLogLevel = logLevelEnvVariable && logLevelEnvVariable in levels ? levels[logLevelEnvVariable] : levels.DEBUG;
    if (levels.DEBUG.priority >= lambdaLogLevel.priority) {
      this.debug = (message, ...optionalParams) => {
        const loggingContext = this.ensureDurableLoggingContext();
        const params = message !== void 0 ? [message, ...optionalParams] : optionalParams;
        this.consoleLogger.debug(formatDurableLogData(DurableLogLevel.DEBUG, loggingContext.getDurableLogData(), ...params));
      };
    }
    if (levels.INFO.priority >= lambdaLogLevel.priority) {
      this.info = (message, ...optionalParams) => {
        const loggingContext = this.ensureDurableLoggingContext();
        const params = message !== void 0 ? [message, ...optionalParams] : optionalParams;
        this.consoleLogger.info(formatDurableLogData(DurableLogLevel.INFO, loggingContext.getDurableLogData(), ...params));
      };
    }
    if (levels.WARN.priority >= lambdaLogLevel.priority) {
      this.warn = (message, ...optionalParams) => {
        const loggingContext = this.ensureDurableLoggingContext();
        const params = message !== void 0 ? [message, ...optionalParams] : optionalParams;
        this.consoleLogger.warn(formatDurableLogData(DurableLogLevel.WARN, loggingContext.getDurableLogData(), ...params));
      };
    }
    if (levels.ERROR.priority >= lambdaLogLevel.priority) {
      this.error = (message, ...optionalParams) => {
        const loggingContext = this.ensureDurableLoggingContext();
        const params = message !== void 0 ? [message, ...optionalParams] : optionalParams;
        this.consoleLogger.error(formatDurableLogData(DurableLogLevel.ERROR, loggingContext.getDurableLogData(), ...params));
      };
    }
  }
  ensureDurableLoggingContext() {
    const context = this.executionContext;
    if (!this.durableLoggingContext && !context) {
      throw new Error("DurableLoggingContext is not configured. Please call configureDurableLoggingContext before logging.");
    }
    if (this.durableLoggingContext) {
      return this.durableLoggingContext;
    }
    if (!context) {
      throw new Error("Execution context is not provided.");
    }
    return {
      getDurableLogData: () => {
        return {
          requestId: context.requestId,
          executionArn: context.durableExecutionArn,
          tenantId: context.tenantId
        };
      }
    };
  }
  log(level, message, ...optionalParams) {
    switch (level) {
      case DurableLogLevel.DEBUG:
        this.debug(message, ...optionalParams);
        break;
      case DurableLogLevel.INFO:
        this.info(message, ...optionalParams);
        break;
      case DurableLogLevel.WARN:
        this.warn(message, ...optionalParams);
        break;
      case DurableLogLevel.ERROR:
        this.error(message, ...optionalParams);
        break;
      default:
        this.info(message, ...optionalParams);
        break;
    }
  }
  // These method signatures will be set dynamically in configureLogLevel()
  info;
  error;
  warn;
  debug;
  configureDurableLoggingContext(durableLoggingContext) {
    this.durableLoggingContext = durableLoggingContext;
  }
};
var createDefaultLogger = (executionContext) => {
  return new DefaultLogger(executionContext);
};
var ActiveOperationsTracker = class {
  activeCount = 0;
  /**
   * Increment the counter when starting an async operation
   */
  increment() {
    this.activeCount++;
  }
  /**
   * Decrement the counter when an async operation completes
   */
  decrement() {
    this.activeCount = Math.max(0, this.activeCount - 1);
  }
  /**
   * Check if there are any active operations
   */
  hasActive() {
    return this.activeCount > 0;
  }
  /**
   * Get the current count of active operations
   */
  getCount() {
    return this.activeCount;
  }
  /**
   * Reset the counter (useful for testing)
   */
  reset() {
    this.activeCount = 0;
  }
};
var defaultLambdaClient;
var DurableExecutionApiClient = class {
  client;
  constructor(client) {
    if (!client) {
      if (!defaultLambdaClient) {
        defaultLambdaClient = new import_client_lambda.LambdaClient({
          requestHandler: {
            connectionTimeout: 5e3,
            socketTimeout: 5e4,
            requestTimeout: 55e3,
            throwOnRequestTimeout: true
          }
        });
      }
      this.client = defaultLambdaClient;
    } else {
      this.client = client;
    }
  }
  /**
   * Gets operation state data from the durable execution
   * @param params - The GetDurableExecutionState request
   * @param logger - Optional developer logger for error reporting
   * @returns Response with operations data
   */
  async getExecutionState(params, logger) {
    try {
      const response = await this.client.send(new import_client_lambda.GetDurableExecutionStateCommand({
        DurableExecutionArn: params.DurableExecutionArn,
        CheckpointToken: params.CheckpointToken,
        Marker: params.Marker,
        MaxItems: params.MaxItems
      }));
      return response;
    } catch (error) {
      log("\u274C", "GetDurableExecutionState failed", {
        error,
        requestId: error?.$metadata?.requestId,
        DurableExecutionArn: params.DurableExecutionArn,
        CheckpointToken: params.CheckpointToken,
        Marker: params.Marker
      });
      if (logger) {
        logger.error("Failed to get durable execution state", error, {
          requestId: error?.$metadata?.requestId
        });
      }
      throw error;
    }
  }
  /**
   * Checkpoints the durable execution with operation updates
   * @param params - The checkpoint request
   * @param logger - Optional developer logger for error reporting
   * @returns Checkpoint response
   */
  async checkpoint(params, logger) {
    try {
      const response = await this.client.send(new import_client_lambda.CheckpointDurableExecutionCommand({
        DurableExecutionArn: params.DurableExecutionArn,
        CheckpointToken: params.CheckpointToken,
        ClientToken: params.ClientToken,
        Updates: params.Updates
      }));
      return response;
    } catch (error) {
      log("\u274C", "CheckpointDurableExecution failed", {
        error,
        requestId: error?.$metadata?.requestId,
        DurableExecutionArn: params.DurableExecutionArn,
        CheckpointToken: params.CheckpointToken,
        ClientToken: params.ClientToken
      });
      if (logger) {
        logger.error("Failed to checkpoint durable execution", error, {
          requestId: error?.$metadata?.requestId
        });
      }
      throw error;
    }
  }
};
var DurableExecutionInvocationInputWithClient = class {
  durableExecutionClient;
  InitialExecutionState;
  DurableExecutionArn;
  CheckpointToken;
  constructor(params, durableExecutionClient) {
    this.durableExecutionClient = durableExecutionClient;
    this.InitialExecutionState = params.InitialExecutionState;
    this.DurableExecutionArn = params.DurableExecutionArn;
    this.CheckpointToken = params.CheckpointToken;
  }
};
var initializeExecutionContext = async (event, context, lambdaClient) => {
  log("\u{1F535}", "Initializing durable function with event:", event);
  log("\u{1F4CD}", "Function Input:", event);
  const checkpointToken = event.CheckpointToken;
  const durableExecutionArn = event.DurableExecutionArn;
  const durableExecutionClient = (
    // Allow passing arbitrary durable clients if the input is a custom class
    event instanceof DurableExecutionInvocationInputWithClient ? event.durableExecutionClient : new DurableExecutionApiClient(lambdaClient)
  );
  const initLogger = createDefaultLogger({
    durableExecutionArn,
    requestId: context.awsRequestId,
    tenantId: context.tenantId
  });
  const operationsArray = [...event.InitialExecutionState.Operations || []];
  let nextMarker = event.InitialExecutionState.NextMarker;
  while (nextMarker) {
    const response = await durableExecutionClient.getExecutionState({
      CheckpointToken: checkpointToken,
      Marker: nextMarker,
      DurableExecutionArn: durableExecutionArn,
      MaxItems: 1e3
    }, initLogger);
    operationsArray.push(...response.Operations || []);
    nextMarker = response.NextMarker || "";
  }
  const durableExecutionMode = operationsArray.length > 1 ? DurableExecutionMode.ReplayMode : DurableExecutionMode.ExecutionMode;
  log("\u{1F4DD}", "Operations:", operationsArray);
  const stepData = operationsArray.reduce((acc, operation) => {
    if (operation.Id) {
      acc[operation.Id] = operation;
    }
    return acc;
  }, {});
  log("\u{1F4DD}", "Loaded step data:", stepData);
  return {
    executionContext: {
      durableExecutionClient,
      _stepData: stepData,
      terminationManager: new TerminationManager(),
      activeOperationsTracker: new ActiveOperationsTracker(),
      durableExecutionArn,
      pendingCompletions: /* @__PURE__ */ new Set(),
      getStepData(stepId) {
        return getStepData(stepData, stepId);
      },
      tenantId: context.tenantId,
      requestId: context.awsRequestId
    },
    durableExecutionMode,
    checkpointToken
  };
};
var LAMBDA_RESPONSE_SIZE_LIMIT = 6 * 1024 * 1024 - 50;
async function runHandler(event, context, executionContext, durableExecutionMode, checkpointToken, handler2) {
  const stepDataEmitter = new import_events.EventEmitter();
  const checkpointManager = new CheckpointManager(executionContext.durableExecutionArn, executionContext._stepData, executionContext.durableExecutionClient, executionContext.terminationManager, executionContext.activeOperationsTracker, checkpointToken, stepDataEmitter, createDefaultLogger(executionContext), executionContext.pendingCompletions);
  executionContext.terminationManager.setCheckpointTerminatingCallback(() => {
    checkpointManager.setTerminating();
  });
  const durableExecution = {
    checkpointManager,
    stepDataEmitter,
    setTerminating: () => checkpointManager.setTerminating()
  };
  const durableContext = createDurableContext(
    executionContext,
    context,
    durableExecutionMode,
    // Default logger may not have the same type as Logger, but we should always provide a default logger even if the user overrides it
    createDefaultLogger(),
    void 0,
    durableExecution
  );
  const initialExecutionEvent = event.InitialExecutionState.Operations?.[0];
  const customerHandlerEvent = JSON.parse(initialExecutionEvent?.ExecutionDetails?.InputPayload ?? "{}");
  try {
    log("\u{1F3AF}", `Starting handler execution, handler event: ${customerHandlerEvent}`);
    let handlerPromiseResolved = false;
    let terminationPromiseResolved = false;
    const handlerPromise = runWithContext("root", void 0, () => handler2(customerHandlerEvent, durableContext)).then((result2) => {
      handlerPromiseResolved = true;
      log("\u{1F3C6}", "Handler promise resolved first!");
      return ["handler", result2];
    });
    const terminationPromise = executionContext.terminationManager.getTerminationPromise().then((result2) => {
      terminationPromiseResolved = true;
      log("\u{1F4A5}", "Termination promise resolved first!");
      durableExecution.setTerminating();
      return ["termination", result2];
    });
    setTimeout(() => {
      log("\u23F1\uFE0F", "Promise race status check:", {
        handlerResolved: handlerPromiseResolved,
        terminationResolved: terminationPromiseResolved
      });
    }, 500);
    const [resultType, result] = await Promise.race([
      handlerPromise,
      terminationPromise
    ]);
    log("\u{1F3C1}", "Promise race completed with:", {
      resultType
    });
    try {
      await durableExecution.checkpointManager.waitForQueueCompletion();
      log("\u2705", "All pending checkpoints completed");
    } catch (error) {
      log("\u26A0\uFE0F", "Error waiting for checkpoint completion:", error);
    }
    if (resultType === "termination" && result.reason === TerminationReason.CHECKPOINT_FAILED) {
      log("\u{1F6D1}", "Checkpoint failed - handling termination");
      throw result.error;
    }
    if (resultType === "termination" && result.reason === TerminationReason.SERDES_FAILED) {
      log("\u{1F6D1}", "Serdes failed - terminating Lambda execution");
      throw new SerdesFailedError(result.message);
    }
    if (resultType === "termination" && result.reason === TerminationReason.CONTEXT_VALIDATION_ERROR) {
      log("\u{1F6D1}", "Context validation error - returning FAILED status");
      return {
        Status: InvocationStatus.FAILED,
        Error: createErrorObjectFromError(result.error || new Error(result.message))
      };
    }
    if (resultType === "termination") {
      log("\u{1F6D1}", "Returning termination response");
      return {
        Status: InvocationStatus.PENDING
      };
    }
    log("\u2705", "Returning normal completion response");
    const serializedResult = JSON.stringify(result);
    const serializedSize = new TextEncoder().encode(serializedResult).length;
    if (serializedResult && serializedSize > LAMBDA_RESPONSE_SIZE_LIMIT) {
      log("\u{1F4E6}", `Response size (${serializedSize} bytes) exceeds Lambda limit (${LAMBDA_RESPONSE_SIZE_LIMIT} bytes). Checkpointing result.`);
      const stepId = `execution-result-${Date.now()}`;
      try {
        await durableExecution.checkpointManager.checkpoint(stepId, {
          Id: stepId,
          Action: "SUCCEED",
          Type: import_client_lambda.OperationType.EXECUTION,
          Payload: serializedResult
          // Reuse the already serialized result
        });
        log("\u2705", "Large result successfully checkpointed");
        return {
          Status: InvocationStatus.SUCCEEDED,
          Result: ""
        };
      } catch (checkpointError) {
        log("\u274C", "Failed to checkpoint large result:", checkpointError);
        throw checkpointError;
      }
    }
    return {
      Status: InvocationStatus.SUCCEEDED,
      Result: serializedResult
    };
  } catch (error) {
    log("\u274C", "Handler threw an error:", error);
    if (isUnrecoverableInvocationError(error)) {
      log("\u{1F6D1}", "Unrecoverable invocation error - terminating Lambda execution");
      throw error;
    }
    return {
      Status: InvocationStatus.FAILED,
      Error: createErrorObjectFromError(error)
    };
  }
}
function validateDurableExecutionEvent(event) {
  try {
    const eventObj = event;
    if (!eventObj?.DurableExecutionArn || !eventObj?.CheckpointToken) {
      throw new Error("Missing required durable execution fields");
    }
  } catch {
    const msg = `Unexpected payload provided to start the durable execution. 
Check your resource configurations to confirm the durability is set.`;
    throw new Error(msg);
  }
}
var withDurableExecution = (handler2, config) => {
  return async (event, context) => {
    validateDurableExecutionEvent(event);
    const { executionContext, durableExecutionMode, checkpointToken } = await initializeExecutionContext(event, context, config?.client);
    let response = null;
    try {
      response = await runHandler(event, context, executionContext, durableExecutionMode, checkpointToken, handler2);
      return response;
    } catch (err) {
      throw err;
    }
  };
};
var DEFAULT_CONFIG = {
  maxAttempts: 60,
  initialDelay: { seconds: 5 },
  maxDelay: { seconds: 300 },
  // 5 minutes
  backoffRate: 1.5,
  jitter: JitterStrategy.FULL,
  timeoutSeconds: void 0
  // No timeout by default
};

// app.ts
var handler = withDurableExecution(
  async (event, context) => {
    const { seatId, userId } = event;
    const reservation = await context.step(async (stepContext) => {
      const reservationId = crypto.randomUUID();
      const now = /* @__PURE__ */ new Date();
      const expiresAt = new Date(now.getTime() + 15 * 60 * 1e3);
      stepContext.logger.info(`[STEP 1] Creating hold for seat: ${seatId}`);
      stepContext.logger.info(`[STEP 1] Reservation ID: ${reservationId}`);
      const data = {
        reservationId,
        seatId,
        userId,
        status: "held",
        createdAt: now.toISOString(),
        expiresAt: expiresAt.toISOString()
      };
      return data;
    });
    context.logger.info(`[WAIT] Sleeping for 15 minutes...`);
    await context.wait({ seconds: 30 });
    const finalResult = await context.step(async (stepContext) => {
      stepContext.logger.info(`[STEP 2] Finalizing reservation ${reservation.reservationId}`);
      return {
        ...reservation,
        status: "expired",
        expiredAt: (/* @__PURE__ */ new Date()).toISOString()
      };
    });
    return {
      message: "Reservation workflow completed",
      reservation: finalResult
    };
  }
);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
