declare const _default: {
    preset: string;
    testEnvironment: string;
    testMatch: string[];
    moduleFileExtensions: string[];
};
export default _default;
